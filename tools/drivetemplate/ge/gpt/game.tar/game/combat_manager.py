class CombatManager:
    def __init__(self, map_buttons, player_stats, enemy_stats):
        """
        Initializes the CombatManager with references to the map buttons
        and the stats for the player and enemies.
        """
        self.map_buttons = map_buttons  # Reference to the map buttons
        self.player_stats = player_stats  # Dictionary containing player stats (e.g., HP, ammo)
        self.enemy_stats = enemy_stats  # Dictionary containing enemy stats (e.g., HP)

    def player_attack(self, target_coord, enemy_positions):
        """
        Handles the player's attack on an enemy unit.
        Args:
            target_coord (str): The coordinate of the enemy being attacked.
            enemy_positions (list): The list of current enemy positions.
        Returns:
            str: A message describing the result of the attack.
        """
        if target_coord in enemy_positions:
            # Reduce enemy health
            self.enemy_stats["hp"] -= 5  # Adjust damage value as needed
            if self.enemy_stats["hp"] <= 0:
                # Enemy defeated, remove from the map
                self.map_buttons[target_coord].config(text="Empty", bg="lightgray")
                enemy_positions.remove(target_coord)
                return f"Enemy at {target_coord} is defeated!"
            else:
                return f"Enemy at {target_coord} HP reduced to {self.enemy_stats['hp']}."
        return "No enemy to attack at the selected position."

    def enemy_attack(self, player_position):
        """
        Handles the enemy's attack on the player unit.
        Args:
            player_position (str): The current position of the player unit.
        Returns:
            str: A message describing the result of the attack.
        """
        # Enemy attack reduces player health
        self.player_stats["hp"] -= 5  # Adjust damage value as needed
        if self.player_stats["hp"] <= 0:
            return "Player is defeated!"
        return f"Player HP reduced to {self.player_stats['hp']}."