import random

class UnitManager:
    def __init__(self, map_buttons, terrain_manager, enemy_count):
        """
        Initializes the UnitManager with references to map buttons, terrain, and enemy count.
        """
        self.map_buttons = map_buttons  # Reference to the map buttons
        self.terrain_manager = terrain_manager  # Reference to the terrain manager
        self.player_position = "A1"  # Initial player position
        self.enemy_positions = []  # List of enemy positions
        self.enemy_count = enemy_count  # Total number of enemies to deploy

    def deploy_player(self, player_unit_name):
        """
        Deploys the player unit on a random empty tile.
        """
        for _ in range(5):  # Retry up to 5 times for deployment
            self.player_position = random.choice(list(self.map_buttons.keys()))
            if self.terrain_manager.get_terrain(self.player_position) == "Empty":
                self.map_buttons[self.player_position].config(text=player_unit_name, bg="blue")
                return self.player_position
        # Raise an exception if deployment fails
        raise ValueError("Failed to deploy player unit. Restart required.")

    def deploy_enemies(self, enemy_unit_name):
        """
        Deploys enemy units on random empty tiles.
        """
        empty_cells = [
            coord for coord, terr in self.terrain_manager.terrain.items()
            if terr == "Empty" and self.map_buttons[coord].cget("text") == "Empty"
        ]
        if len(empty_cells) < self.enemy_count:
            raise ValueError("Not enough empty spaces to deploy enemies.")

        self.enemy_positions = random.sample(empty_cells, self.enemy_count)
        for enemy_position in self.enemy_positions:
            self.map_buttons[enemy_position].config(text=enemy_unit_name, bg="red")
        return self.enemy_positions

    def move_unit(self, current_position, target_position, unit_name):
        """
        Moves a unit from the current position to the target position.
        """
        self.map_buttons[current_position].config(text="Empty", bg="lightgray")
        self.map_buttons[target_position].config(text=unit_name, bg="blue")
        return target_position

    def move_enemy(self, enemy_position, target_position, enemy_name):
        """
        Moves an enemy unit from the current position to the target position.
        """
        self.map_buttons[enemy_position].config(text="Empty", bg="lightgray")
        self.map_buttons[target_position].config(text=enemy_name, bg="red")
        return target_position

    def is_adjacent(self, pos1, pos2):
        """
        Determines whether two positions on the map are adjacent.
        """
        row_diff = abs(ord(pos1[0]) - ord(pos2[0]))
        col_diff = abs(int(pos1[1]) - int(pos2[1]))
        return max(row_diff, col_diff) == 1