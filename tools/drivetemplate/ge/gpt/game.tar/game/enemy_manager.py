import random

class EnemyManager:
    def __init__(self, map_buttons, terrain_manager, enemy_count):
        """
        Initializes the EnemyManager with references to the map buttons,
        terrain manager, and the number of enemy units.
        """
        self.map_buttons = map_buttons  # Reference to map buttons
        self.terrain_manager = terrain_manager  # Reference to terrain manager
        self.enemy_positions = []  # List of enemy positions
        self.enemy_count = enemy_count  # Number of enemy units

    def deploy_enemies(self, enemy_unit_name):
        """
        Deploys enemy units on random empty tiles.
        Args:
            enemy_unit_name (str): The name of the enemy units (e.g., "Enemy Unit").
        Returns:
            list: A list of coordinates where the enemies are deployed.
        Raises:
            ValueError: If there are not enough empty spaces for deployment.
        """
        empty_cells = [
            coord for coord, terr in self.terrain_manager.terrain.items()
            if terr == "Empty" and self.map_buttons[coord].cget("text") == "Empty"
        ]
        if len(empty_cells) < self.enemy_count:
            raise ValueError("Not enough empty spaces to deploy enemies.")

        self.enemy_positions = random.sample(empty_cells, self.enemy_count)
        for enemy_position in self.enemy_positions:
            self.map_buttons[enemy_position].config(text=enemy_unit_name, bg="red")
        return self.enemy_positions

    def move_toward_player(self, enemy_position, player_position, enemy_name):
        """
        Moves an enemy unit toward the player.
        Args:
            enemy_position (str): The current position of the enemy unit.
            player_position (str): The current position of the player unit.
            enemy_name (str): The name of the enemy unit (e.g., "Enemy Unit").
        Returns:
            str: The new position of the enemy unit.
        """
        player_row, player_col = ord(player_position[0]), int(player_position[1])
        enemy_row, enemy_col = ord(enemy_position[0]), int(enemy_position[1])
        dr = player_row - enemy_row
        dc = player_col - enemy_col

        # Determine the direction of movement
        if abs(dr) > abs(dc):
            new_pos = f"{chr(enemy_row + (1 if dr > 0 else -1))}{enemy_col}"
        else:
            new_pos = f"{chr(enemy_row)}{enemy_col + (1 if dc > 0 else -1)}"

        # Validate and perform the move
        if new_pos in self.map_buttons and self.terrain_manager.get_terrain(new_pos) in ["Empty", "Forest"]:
            self.map_buttons[enemy_position].config(text="Empty", bg="lightgray")
            self.map_buttons[new_pos].config(text=enemy_name, bg="red")
            return new_pos

        # Stay in place if movement is invalid
        return enemy_position

    def is_adjacent(self, pos1, pos2):
        """
        Checks if two positions are adjacent on the map.
        Args:
            pos1 (str): The first position (e.g., "A1").
            pos2 (str): The second position (e.g., "B2").
        Returns:
            bool: True if the positions are adjacent, False otherwise.
        """
        row_diff = abs(ord(pos1[0]) - ord(pos2[0]))
        col_diff = abs(int(pos1[1]) - int(pos2[1]))
        return max(row_diff, col_diff) == 1