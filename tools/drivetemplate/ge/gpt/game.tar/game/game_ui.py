import tkinter as tk
import tempfile

class GameUI:
    def __init__(self, root):
        """
        Initializes the GameUI with a persistent, always-visible log area on top and
        dynamically sized map cells below. Log messages are written to a temporary file
        as well as shown in the UI.
        """
        self.root = root
        
        # Main container for layout
        self.main_frame = tk.Frame(root)
        self.main_frame.pack(fill="both", expand=True)
        
        # Get screen dimensions (for button sizing)
        self.screen_width = self.root.winfo_screenwidth()
        self.screen_height = self.root.winfo_screenheight()
        
        self.map_buttons = {}      # Will hold our map grid buttons
        self.cell_states = {}      # Will hold the state (text) for each cell
        
        # Create a temporary file to store log messages
        self.log_file = tempfile.NamedTemporaryFile(mode='w+', delete=False, suffix='.log')
        self.write_log("Game log initialized. Log file: " + self.log_file.name)
        
        # Create the log area at the top
        self.create_log_area()
        
        # Create a container for the game map below the log area
        self.map_frame = tk.Frame(self.main_frame)
        self.map_frame.pack(side="top", fill="both", expand=True)
        
    def create_map(self, rows, cols, on_cell_click):
        """
        Creates a dynamically sized map grid of buttons that should fit on the screen.
        """
        # Clear any existing map buttons
        for widget in self.map_frame.winfo_children():
            widget.destroy()
        self.map_buttons.clear()

        # Compute button size based on screen dimensions and desired grid size.
        # (Adjust the divisor constants to fit your needs.)
        button_width = int(self.screen_width / cols / 10)
        button_height = int((self.screen_height / 1.5) / rows / 10)

        # Create the grid
        for row in range(rows):
            for col in range(cols):
                coord = f"{chr(65 + row)}{col + 1}"  # e.g., A1, B1, ...
                cell_value = self.cell_states.get(coord, "Empty")
                button = tk.Button(
                    self.map_frame,
                    text=cell_value,
                    width=button_width,
                    height=button_height,
                    command=lambda c=coord: on_cell_click(c)
                )
                button.grid(row=row, column=col, sticky="nsew")
                self.map_buttons[coord] = button

        # Ensure grid resizing works nicely
        for r in range(rows):
            self.map_frame.rowconfigure(r, weight=1)
        for c in range(cols):
            self.map_frame.columnconfigure(c, weight=1)

    def create_log_area(self):
        """
        Creates a persistent, scrollable log area at the top of the screen.
        """
        self.log_frame = tk.Frame(self.main_frame)
        self.log_frame.pack(side="top", fill="x")
        # Create the scrollbar for the log
        self.scrollbar = tk.Scrollbar(self.log_frame, orient="vertical")
        self.scrollbar.pack(side="right", fill="y")
        # Create the log text area.
        # Set state to "normal" initially so we can insert text.
        self.log_area = tk.Text(
            self.log_frame,
            height=5,
            width=50,
            state="normal",
            wrap="word",
            yscrollcommand=self.scrollbar.set
        )
        self.log_area.pack(side="left", fill="both", expand=True)
        self.scrollbar.config(command=self.log_area.yview)
        # Start with an initialization message visible.
        self.log_area.insert(tk.END, "Log initialized successfully.\n")
        self.log_area.see(tk.END)
        self.log_area.configure(state="disabled")

    def update_cell_state(self, coord, value):
        """
        Updates the displayed text for a given cell on the map.
        """
        self.cell_states[coord] = value
        if coord in self.map_buttons:
            self.map_buttons[coord].config(text=value)

    def update_log(self, message):
        """
        Updates the game log (both in the UI and in a temporary log file)
        with a human-readable message.
        """
        # First, update the UI log area.
        self.log_area.configure(state="normal")
        self.log_area.insert(tk.END, message + "\n")
        self.log_area.see(tk.END)
        self.log_area.configure(state="disabled")
        # Then write the same message to the temporary log file.
        self.write_log(message)

    def write_log(self, message):
        """
        Writes a log message to the temporary log file.
        """
        if self.log_file:
            self.log_file.write(message + "\n")
            self.log_file.flush()

    def show_end_screen(self, message):
        """
        Displays a popup window with a victory or defeat message.
        """
        end_screen = tk.Toplevel(self.root)
        end_screen.title("Game Over")
        label = tk.Label(end_screen, text=message, font=("Arial", 16), padx=20, pady=20)
        label.pack()
        close_button = tk.Button(end_screen, text="Close Game", command=self.root.destroy)
        close_button.pack(pady=10)