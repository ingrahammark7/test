import tkinter as tk
from tkinter import ttk

class GameUI:
    def __init__(self, root):
        """
        Initializes the GameUI with a scrollable map, zoom controls, and a persistent log box.
        """
        self.root = root

        # Main container for layout organization
        self.main_frame = tk.Frame(self.root)
        self.main_frame.pack(fill="both", expand=True)

        # Create a canvas for the map with a vertical scrollbar
        self.canvas = tk.Canvas(self.main_frame)
        self.scrollbar = ttk.Scrollbar(self.main_frame, orient="vertical", command=self.canvas.yview)
        self.scrollable_frame = tk.Frame(self.canvas)

        # Add the scrollable frame to the canvas
        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        )
        self.canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")

        # Configure the canvas and scrollbar
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")

        # Initialize zoom state and map buttons
        self.zoom_level = 1.0
        self.map_buttons = {}
        self.cell_states = {}  # Store each cell's current value (terrain, units, etc.)

        # Create zoom controls
        self.create_zoom_controls()

        # Create the log area below the map
        self.create_log_area()

    def create_map(self, rows, cols, on_cell_click):
        """
        Creates a dynamically zoomable map grid of buttons.
        """
        # Clear any existing map buttons
        for widget in self.scrollable_frame.winfo_children():
            widget.destroy()
        self.map_buttons.clear()

        # Generate the map grid
        for row in range(rows):
            for col in range(cols):
                coord = f"{chr(65 + row)}{col + 1}"  # Example: A1, B1, etc.

                # Get the saved state (e.g., terrain type) for the cell, or default to "Empty"
                cell_value = self.cell_states.get(coord, "Empty")

                button = tk.Button(
                    self.scrollable_frame,
                    text=cell_value,
                    width=int(10 * self.zoom_level),  # Adjusted width for zoom
                    height=int(3 * self.zoom_level),  # Adjusted height for zoom
                    command=lambda c=coord: on_cell_click(c)
                )
                button.grid(row=row, column=col)
                self.map_buttons[coord] = button

        # Update the scrollable area
        self.canvas.update_idletasks()

    def create_zoom_controls(self):
        """
        Adds Zoom In and Zoom Out buttons to the UI.
        """
        control_frame = tk.Frame(self.root)
        control_frame.pack(side="top", fill="x")

        zoom_in_button = tk.Button(control_frame, text="Zoom In", command=self.zoom_in)
        zoom_in_button.pack(side="left", padx=10, pady=5)

        zoom_out_button = tk.Button(control_frame, text="Zoom Out", command=self.zoom_out)
        zoom_out_button.pack(side="left", padx=10, pady=5)

    def zoom_in(self):
        """
        Increases the zoom level and redraws the map.
        """
        if self.zoom_level < 2.0:  # Limit maximum zoom level
            self.zoom_level += 0.2
            self.update_zoom()

    def zoom_out(self):
        """
        Decreases the zoom level and redraws the map.
        """
        max_zoom_out = self.calculate_max_zoom_out()
        if self.zoom_level > max_zoom_out:  # Ensure we don't shrink too much
            self.zoom_level -= 0.2
            self.update_zoom()

    def calculate_max_zoom_out(self):
        """
        Dynamically calculates the maximum zoom-out level based on screen size.
        """
        screen_width = self.root.winfo_screenwidth() // 100
        screen_height = self.root.winfo_screenheight() // 50

        max_width_zoom = screen_width / 3 # Adjust for 7 columns
        max_height_zoom = screen_height / 3  # Adjust for 7 rows

        return min(max_width_zoom, max_height_zoom)  # Use the smaller of the two values

    def update_zoom(self):
        """
        Redraws the map at the new zoom level.
        """
        rows = len(self.map_buttons) // 7  # Assume 7x7 grid for now
        self.create_map(rows, 7, lambda x: None)  # Redraw with updated zoom level

    def update_cell_state(self, coord, value):
        """
        Updates the state of a specific cell (e.g., terrain type, units).
        """
        self.cell_states[coord] = value
        if coord in self.map_buttons:
            self.map_buttons[coord].config(text=value)

    def create_log_area(self):
        """
        Creates a text area to display the game log.
        """
        self.log_area = tk.Text(self.root, height=5, width=50, state="normal", wrap="word")
        self.log_area.pack(side="bottom", fill="x")

    def update_log(self, message):
        """
        Updates the game log with a new message.
        """
        if self.log_area:
            self.log_area.configure(state="normal")
            self.log_area.insert(tk.END, message + "\n")
            self.log_area.see(tk.END)
            self.log_area.configure(state="disabled")

    def show_end_screen(self, message):
        """
        Displays a popup with a victory or defeat message.
        """
        end_screen = tk.Toplevel(self.root)
        end_screen.title("Game Over")
        label = tk.Label(end_screen, text=message, font=("Arial", 16), padx=20, pady=20)
        label.pack()
        close_button = tk.Button(end_screen, text="Close Game", command=self.root.destroy)
        close_button.pack(pady=10)