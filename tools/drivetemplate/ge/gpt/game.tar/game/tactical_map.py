import tkinter as tk
from game_ui import GameUI
from terrain_manager import TerrainManager
from player_manager import PlayerManager
from enemy_manager import EnemyManager
from combat_manager import CombatManager

class TacticalMap:
    def __init__(self, root):
        """
        Initializes the TacticalMap, setting up the game managers and the UI.
        """
        self.ui = GameUI(root)
        self.terrain_manager = TerrainManager(self.ui.map_buttons)
        self.player_manager = PlayerManager(self.ui.map_buttons, self.terrain_manager)
        self.enemy_manager = EnemyManager(self.ui.map_buttons, self.terrain_manager, enemy_count=5)
        self.combat_manager = CombatManager(
            self.ui.map_buttons,
            player_stats={"name": "T-64 Tank", "hp": 20, "ammo": 5},
            enemy_stats={"name": "Enemy Unit", "hp": 10}
        )

        # General game state
        self.player_unit = "T-64 Tank"
        self.enemy_unit = "Enemy Unit"
        self.turn = "Player"
        self.crossing_turns = 0
        self.target_position = None

        self.initialize_game()

    def initialize_game(self):
        """
        Initializes the game, including map creation, terrain generation,
        and unit deployment.
        Retries until a valid game state is generated.
        """
        self.ui.create_map(rows=7, cols=7, on_cell_click=self.on_cell_click)
        self.ui.create_log_area()

        # Retry generating terrain until successful
        for _ in range(5):  # Maximum of 5 retries
            if self.terrain_manager.generate_terrain(enemy_count=5):
                try:
                    self.player_manager.deploy_player(self.player_unit)
                    self.enemy_manager.deploy_enemies(self.enemy_unit)
                    self.ui.update_log("Game initialized. Player's turn begins.")
                    return
                except ValueError:
                    self.ui.update_log("Deployment failed. Retrying...")
        # If retries fail, restart the game
        self.ui.update_log("Failed to initialize game. Restarting...")
        self.restart_game()

    def restart_game(self):
        """
        Restarts the game by clearing existing states and reinitializing.
        """
        self.ui.update_log("Restarting game...")
        self.enemy_manager.enemy_positions.clear()
        self.player_manager.player_position = None  # Clear previous player position
        self.initialize_game()

    def on_cell_click(self, coord):
        """
        Handles player's action upon clicking a cell.
        """
        if self.turn == "Player" and self.crossing_turns == 0:
            self.handle_player_action(coord)

    def handle_player_action(self, coord):
        """
        Processes player actions: move, attack, or terrain interaction.
        """
        distance_row = abs(ord(coord[0]) - ord(self.player_manager.player_position[0]))
        distance_col = abs(int(coord[1]) - int(self.player_manager.player_position[1]))
        if max(distance_row, distance_col) == 1:  # Check adjacency
            if coord in self.enemy_manager.enemy_positions:
                result = self.combat_manager.player_attack(coord, self.enemy_manager.enemy_positions)
                self.ui.update_log(result)
                if "defeated" in result and not self.enemy_manager.enemy_positions:
                    self.end_game(victory=True)  # Trigger victory if no enemies remain
            elif self.terrain_manager.get_terrain(coord) in ["Empty", "Forest"]:
                self.player_manager.player_position = self.player_manager.move_player(coord, self.player_unit)
                self.end_turn()
            elif self.terrain_manager.get_terrain(coord) == "Water":
                self.start_crossing(coord, turns=2)
            elif self.terrain_manager.get_terrain(coord) == "Mountain":
                self.start_crossing(coord, turns=3)
            else:
                self.ui.update_log("Cannot interact with that terrain!")
        else:
            self.ui.update_log("Invalid move. Choose an adjacent tile.")

    def start_crossing(self, coord, turns):
        """
        Handles crossing of water or mountain tiles by automatically moving
        into the next empty square in the specified direction.
        """
        self.ui.update_log(f"Starting to cross towards {coord}. This will take {turns} turn(s).")
        self.crossing_turns = turns
        self.target_position = coord
        self.end_turn()  # Enemy action while crossing happens

    def process_crossing(self):
        """
        Moves the player automatically toward the target, avoiding obstacles.
        """
        if self.crossing_turns > 0:
            # Calculate next move direction
            self.crossing_turns -= 1
            player_row, player_col = ord(self.player_manager.player_position[0]), int(self.player_manager.player_position[1])
            target_row, target_col = ord(self.target_position[0]), int(self.target_position[1])

            if player_row < target_row:  # Move down
                next_position = f"{chr(player_row + 1)}{player_col}"
            elif player_row > target_row:  # Move up
                next_position = f"{chr(player_row - 1)}{player_col}"
            elif player_col < target_col:  # Move right
                next_position = f"{chr(player_row)}{player_col + 1}"
            elif player_col > target_col:  # Move left
                next_position = f"{chr(player_row)}{player_col - 1}"
            else:
                next_position = self.player_manager.player_position  # Stay in place if no valid move

            # Check if the next position is empty or traversable
            terrain = self.terrain_manager.get_terrain(next_position)
            if terrain in ["Empty", "Forest"]:
                self.player_manager.player_position = self.player_manager.move_player(next_position, self.player_unit)
                self.ui.update_log(f"Moved to {next_position}. {self.crossing_turns} turn(s) left to cross.")
            else:
                self.ui.update_log(f"Cannot move into {next_position} due to {terrain}. Waiting...")

            self.end_turn()
        else:
            # Crossing complete
            self.ui.update_log(f"Crossing complete. Reached {self.target_position}.")
            self.target_position = None
            self.end_turn()

    def enemy_action(self):
        """
        Processes enemy actions: attack if adjacent, otherwise move closer.
        """
        self.ui.update_log("Enemies are taking their turn...")
        new_positions = []
        for enemy_pos in self.enemy_manager.enemy_positions:
            if self.enemy_manager.is_adjacent(enemy_pos, self.player_manager.player_position):
                result = self.combat_manager.enemy_attack(self.player_manager.player_position)
                self.ui.update_log(result)
                if "defeated" in result:
                    self.end_game(victory=False)
                    return
            else:
                new_pos = self.enemy_manager.move_toward_player(
                    enemy_pos, self.player_manager.player_position, self.enemy_unit
                )
                new_positions.append(new_pos)

        self.enemy_manager.enemy_positions = new_positions

        # Check if all enemies are defeated
        if not self.enemy_manager.enemy_positions:
            self.end_game(victory=True)
        else:
            self.end_turn()

    def end_turn(self):
        """
        Switches turns between Player and Enemy, considering crossing state.
        """
        if self.turn == "Player":
            # If crossing, process the next crossing step
            if self.crossing_turns > 0:
                self.turn = "Enemy"
                self.enemy_action()
            else:
                self.turn = "Enemy"
                self.enemy_action()
        else:
            self.turn = "Player"
            if self.crossing_turns > 0:
                self.process_crossing()
            else:
                self.ui.update_log("Player's turn.")

    def end_game(self, victory):
        """
        Ends the game with either a victory or defeat message.
        """
        if victory:
            message = "You Win!"
            self.ui.update_log("Congratulations, Commander! All enemies have been defeated. You are victorious!")
        else:
            message = "Game Over"
            self.ui.update_log("Mission failed. Your forces have been defeated.")

        self.ui.show_end_screen(message)


# Main program entry point
if __name__ == "__main__":
    root = tk.Tk()
    root.title("Turn-Based Tactical Simulation")
    game = TacticalMap(root)
    root.mainloop()