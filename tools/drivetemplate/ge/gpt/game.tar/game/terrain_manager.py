import random

class TerrainManager:
    def __init__(self, map_buttons):
        """
        Initializes the TerrainManager with a reference to the map buttons.
        """
        self.map_buttons = map_buttons  # Reference to the map buttons
        self.terrain = {}  # Dictionary to store terrain types for each cell

    def generate_terrain(self, enemy_count, extra_empty=5):
        """
        Generates terrain for the map and ensures a minimum number of empty tiles.
        Args:
            enemy_count (int): Number of enemies to deploy (affects empty tiles needed).
            extra_empty (int): Extra empty tiles to ensure playability.
        Returns:
            bool: True if terrain generation is successful, False otherwise.
        """
        retries = 5  # Maximum number of attempts to generate a valid map
        for _ in range(retries):
            self.terrain.clear()
            empty_count = 0

            # Randomly assign terrain types to each cell
            for coord in self.map_buttons.keys():
                terrain_type = random.choice(["Forest", "Mountain", "Water", "Empty"])
                self.terrain[coord] = terrain_type
                if terrain_type == "Empty":
                    empty_count += 1

            # Check if enough empty tiles are available
            if empty_count >= enemy_count + extra_empty:
                self._apply_terrain_to_map()
                return True  # Successful generation

        return False  # Failed to generate a valid map after retries

    def _apply_terrain_to_map(self):
        """
        Applies the generated terrain to the map buttons, updating their appearance.
        """
        for coord, terrain_type in self.terrain.items():
            if terrain_type == "Forest":
                self.map_buttons[coord].config(bg="green", text="Forest")
            elif terrain_type == "Mountain":
                self.map_buttons[coord].config(bg="brown", text="Mountain")
            elif terrain_type == "Water":
                self.map_buttons[coord].config(bg="blue", text="Water")
            elif terrain_type == "Empty":
                self.map_buttons[coord].config(bg="lightgray", text="Empty")

    def get_terrain(self, coord):
        """
        Gets the terrain type for a specific coordinate.
        Args:
            coord (str): The map coordinate (e.g., "A1").
        Returns:
            str: The terrain type (e.g., "Forest", "Mountain", "Water", or "Empty").
        """
        return self.terrain.get(coord, "Unknown")