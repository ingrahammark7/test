import random

class PlayerManager:
    def __init__(self, map_buttons, terrain_manager):
        """
        Initializes the PlayerManager with references to the map buttons
        and the terrain manager.
        """
        self.map_buttons = map_buttons  # Reference to the map buttons
        self.terrain_manager = terrain_manager  # Reference to the terrain manager
        self.player_position = None  # The player's starting position

    def deploy_player(self, player_unit_name):
        """
        Deploys the player unit on a random empty tile.
        Args:
            player_unit_name (str): The name of the player unit (e.g., "T-64 Tank").
        Returns:
            str: The coordinate of the deployed player unit.
        Raises:
            ValueError: If deployment fails after multiple attempts.
        """
        for _ in range(10):  # Retry up to 10 times for deployment
            self.player_position = random.choice(list(self.map_buttons.keys()))
            if self.terrain_manager.get_terrain(self.player_position) == "Empty":
                self.map_buttons[self.player_position].config(text=player_unit_name, bg="blue")
                return self.player_position
        raise ValueError("Failed to deploy player unit after multiple attempts.")

    def move_player(self, target_position, unit_name):
        """
        Moves the player unit to a specified target position.
        Args:
            target_position (str): The coordinate to move the player unit to.
            unit_name (str): The name of the player unit (e.g., "T-64 Tank").
        Returns:
            str: The new position of the player unit.
        """
        self.map_buttons[self.player_position].config(text="Empty", bg="lightgray")
        self.map_buttons[target_position].config(text=unit_name, bg="blue")
        self.player_position = target_position
        return self.player_position