"""
config.py

Configuration management for model parameters.

Author: Your Name
"""

import json

def load_config(filepath):
    """
    Load configuration from JSON file.
    """
    with open(filepath, 'r') as f:
        return json.load(f)

def save_config(filepath, config_dict):
    """
    Save configuration dict to JSON file.
    """
    with open(filepath, 'w') as f:
        json.dump(config_dict, f, indent=4)

if __name__ == "__main__":
    example_config = {
        "num_simulations": 10000,
        "macro_steps": 12,
        "tier1_capital": 150e9
    }
    save_config('config.json', example_config)
    loaded = load_config('config.json')
    print("Loaded config:", loaded)
