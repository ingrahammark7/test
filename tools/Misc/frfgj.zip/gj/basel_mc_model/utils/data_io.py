"""
data_io.py

Simple data input/output utilities (e.g. CSV reading/writing).

Author: Your Name
"""

import csv

def read_csv(filepath):
    """
    Reads CSV file into list of dicts.
    """
    with open(filepath, newline='') as f:
        reader = csv.DictReader(f)
        return list(reader)

def write_csv(filepath, data, fieldnames):
    """
    Writes list of dicts to CSV.
    """
    with open(filepath, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(data)

if __name__ == "__main__":
    # Demo reading and writing
    demo_data = [{'name': 'Loan1', 'value': '100'}, {'name': 'Loan2', 'value': '200'}]
    write_csv('demo.csv', demo_data, ['name', 'value'])
    data = read_csv('demo.csv')
    print(data)
