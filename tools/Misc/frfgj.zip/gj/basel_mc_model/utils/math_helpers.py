"""
math_helpers.py

Common math and statistics helper functions.

Author: Your Name
"""

import numpy as np

def weighted_average(values, weights):
    """
    Calculate weighted average.

    Args:
        values: list or np.array of values
        weights: list or np.array of weights (same length)

    Returns:
        float: weighted average
    """
    values = np.array(values)
    weights = np.array(weights)
    if np.sum(weights) == 0:
        return 0
    return np.sum(values * weights) / np.sum(weights)

def pct_change(old, new):
    """
    Calculate percentage change between old and new.

    Returns:
        float
    """
    if old == 0:
        return 0
    return (new - old) / old * 100

if __name__ == "__main__":
    vals = [1, 2, 3]
    wts = [0.2, 0.3, 0.5]
    print("Weighted average:", weighted_average(vals, wts))
    print("Percent change 100->120:", pct_change(100, 120))
