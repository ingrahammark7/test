"""
dashboard.py

Basic dashboard to display summary statistics and plots.

Author: Your Name
"""

from reporting import plotting
from simulation import results_aggregator

def display_dashboard(capital_ratios, losses):
    print("----- Simulation Dashboard -----")
    print(f"Final Capital Ratio: {capital_ratios[-1]*100:.2f}%")

    summary = results_aggregator.summarize_losses(losses)
    print("\nLoss Summary:")
    for k, v in summary.items():
        print(f"{k}: ${v/1e6:.2f}M")

    plotting.plot_capital_ratios(capital_ratios)

if __name__ == "__main__":
    import numpy as np
    capital_ratios = [0.10, 0.095, 0.085, 0.075, 0.07]
    losses = np.random.normal(1e9, 1e8, 1000)
    display_dashboard(capital_ratios, losses)
