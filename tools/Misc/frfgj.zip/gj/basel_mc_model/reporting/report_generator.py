"""
report_generator.py

Generates textual and PDF reports from simulation results.

Author: Your Name
"""

def generate_text_report(capital_ratios, loss_summary):
    report = []
    report.append("=== Basel MC Model Simulation Report ===\n")
    report.append(f"Final Capital Ratio: {capital_ratios[-1]*100:.2f}%\n")
    report.append("Loss Summary:\n")
    for k, v in loss_summary.items():
        report.append(f"  {k}: ${v/1e6:.2f}M\n")
    return "".join(report)

if __name__ == "__main__":
    # Demo usage
    capital_ratios = [0.10, 0.095, 0.085, 0.075]
    loss_summary = {
        "mean_loss": 1.2e9,
        "median_loss": 1.1e9,
        "99th_percentile_loss": 2.0e9,
        "max_loss": 2.5e9
    }
    report = generate_text_report(capital_ratios, loss_summary)
    print(report)
