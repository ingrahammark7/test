"""
plotting.py

Functions for plotting simulation results and risk metrics.

Author: Your Name
"""

import matplotlib.pyplot as plt

def plot_capital_ratios(capital_ratios):
    """
    Plot capital ratio over time.
    """
    months = list(range(1, len(capital_ratios) + 1))
    plt.figure(figsize=(8,5))
    plt.plot(months, [r*100 for r in capital_ratios], marker='o', linestyle='-')
    plt.axhline(8, color='red', linestyle='--', label='Minimum Capital Ratio 8%')
    plt.title('Capital Ratio Over Time')
    plt.xlabel('Month')
    plt.ylabel('Capital Ratio (%)')
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    # Demo plot
    sample_data = [0.10, 0.09, 0.085, 0.07, 0.065, 0.06]
    plot_capital_ratios(sample_data)
