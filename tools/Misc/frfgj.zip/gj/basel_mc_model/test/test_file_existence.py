import os

def check_file_content(filepath):
    if not os.path.exists(filepath):
        return False, "File does not exist"
    with open(filepath, "r", encoding="utf-8") as f:
        content = f.read().strip()
        if len(content) == 0:
            return False, "File is empty"
    return True, "File exists and has content"

def main():
    base_dir = "basel_mc_model"
    files = [
        "credit_risk/portfolio.py",
        "credit_risk/basel_irb.py",
        "credit_risk/default_simulation.py",
        "credit_risk/loss_calculation.py",
        "macro/macro_factors.py",
        "macro/stress_scenarios.py",
        "macro/feedback_loops.py",
        "capital/capital_calculation.py",
        "capital/deleveraging.py",
        "capital/policy_interventions.py",
        "simulation/monte_carlo_runner.py",
        "simulation/scenario_manager.py",
        "simulation/results_aggregator.py",
        "reporting/plotting.py",
        "reporting/dashboard.py",
        "reporting/report_generator.py",
        "utils/math_helpers.py",
        "utils/data_io.py",
        "utils/config.py",
        "main.py"
    ]

    all_pass = True
    for file in files:
        path = os.path.join(base_dir, file) if file != "main.py" else os.path.join(base_dir, file)
        exists, message = check_file_content(path)
        status = "PASS" if exists else "FAIL"
        print(f"{file}: {status} ({message})")
        if not exists:
            all_pass = False

    if all_pass:
        print("\nAll files are present and have content.")
    else:
        print("\nSome files failed the check.")

if __name__ == "__main__":
    main()
