"""
basel_irb.py

Full Basel IRB risk weight formulas including corporate, retail, and mortgage with
maturity adjustments, correlations, and capital requirements.

Author: Your Name
"""

import numpy as np
import scipy.stats as stats

def asset_correlation_corporate(PD):
    """
    Asset correlation function for corporate exposures (Basel IRB).
    """
    exp_component = np.exp(-50 * PD)
    numerator = 0.12 * (1 - exp_component)
    denominator = 1 - np.exp(-50)
    return numerator / denominator + 0.24 * (1 - numerator / denominator)

def b_function(PD):
    """
    Maturity adjustment function b(PD).
    """
    return (0.11852 - 0.05478 * np.log(PD)) ** 2

def risk_weight_corporate(PD, LGD, M=2.5):
    """
    Calculate corporate risk weight per Basel IRB formula.

    Parameters
    ----------
    PD : float
        Probability of default
    LGD : float
        Loss given default
    M : float, optional
        Effective maturity (default 2.5 years)

    Returns
    -------
    float
        Risk weight
    """
    R = asset_correlation_corporate(PD)
    z = stats.norm.ppf(PD)
    z_999 = stats.norm.ppf(0.999)
    maturity_adj = (1 + (M - 2.5) * b_function(PD)) / (1 - 1.5 * b_function(PD))
    numerator = LGD * stats.norm.cdf((z + np.sqrt(R) * z_999) / np.sqrt(1 - R)) - PD * LGD
    denominator = 1 - 1.5 * b_function(PD)
    capital_req = numerator / denominator * 12.5
    return capital_req * maturity_adj

def asset_correlation_retail(PD):
    """
    Retail correlation function (simplified).
    """
    return 0.03

def risk_weight_retail(PD, LGD, M=2.5):
    """
    Retail risk weight (simplified).
    """
    R = asset_correlation_retail(PD)
    z = stats.norm.ppf(PD)
    z_999 = stats.norm.ppf(0.999)
    maturity_adj = (1 + (M - 2.5) * b_function(PD)) / (1 - 1.5 * b_function(PD))
    numerator = LGD * stats.norm.cdf((z + np.sqrt(R) * z_999) / np.sqrt(1 - R)) - PD * LGD
    denominator = 1 - 1.5 * b_function(PD)
    capital_req = numerator / denominator * 12.5
    return capital_req * maturity_adj

if __name__ == "__main__":
    # Demo calculation for corporate exposure
    PD = 0.01
    LGD = 0.45
    rw_corp = risk_weight_corporate(PD, LGD)
    print(f"Corporate Risk Weight: {rw_corp:.4f}")

    # Demo for retail exposure
    PD_r = 0.03
    LGD_r = 0.5
    rw_retail = risk_weight_retail(PD_r, LGD_r)
    print(f"Retail Risk Weight: {rw_retail:.4f}")
