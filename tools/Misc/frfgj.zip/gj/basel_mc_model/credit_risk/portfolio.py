"""
portfolio.py

Loan portfolio and exposure management with data classes and helper functions.

Author: Your Name
"""

from dataclasses import dataclass
from typing import List

@dataclass
class LoanExposure:
    name: str
    EAD: float       # Exposure at Default (dollars)
    PD: float        # Probability of Default
    LGD: float       # Loss Given Default
    M: float = 2.5   # Maturity in years

class LoanPortfolio:
    def __init__(self, loans: List[LoanExposure]):
        self.loans = loans

    def total_EAD(self):
        return sum(loan.EAD for loan in self.loans)

    def get_PD_vector(self):
        return [loan.PD for loan in self.loans]

    def get_LGD_vector(self):
        return [loan.LGD for loan in self.loans]

    def __len__(self):
        return len(self.loans)

def example_portfolio():
    loans = [
        LoanExposure(name="Corporate A", EAD=5e9, PD=0.01, LGD=0.45),
        LoanExposure(name="Corporate B", EAD=3e9, PD=0.03, LGD=0.6),
        LoanExposure(name="SME Loans", EAD=2e9, PD=0.08, LGD=0.7),
    ]
    return LoanPortfolio(loans)

if __name__ == "__main__":
    portfolio = example_portfolio()
    print(f"Portfolio total EAD: ${portfolio.total_EAD()/1e9:.2f} Billion")
    for loan in portfolio.loans:
        print(f"{loan.name}: PD={loan.PD}, LGD={loan.LGD}, EAD=${loan.EAD/1e6:.1f}M")
