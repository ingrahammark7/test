"""
loss_calculation.py

Calculates losses given default and expected losses from default simulation results.

Author: Your Name
"""

import numpy as np

def calculate_loss(default_matrix, portfolio):
    """
    Calculate total loss for each simulation.

    Args:
        default_matrix: numpy boolean array (simulations x loans)
        portfolio: LoanPortfolio instance

    Returns:
        losses: numpy array of total loss per simulation
    """
    num_sims, num_loans = default_matrix.shape
    losses = np.zeros(num_sims)

    for i in range(num_loans):
        loan = portfolio.loans[i]
        # Loss if defaulted = EAD * LGD
        losses += default_matrix[:, i] * (loan.EAD * loan.LGD)

    return losses

def expected_loss(portfolio):
    """
    Calculate expected loss (EL) for the portfolio.

    EL = sum(EAD * PD * LGD)
    """
    return sum(loan.EAD * loan.PD * loan.LGD for loan in portfolio.loans)

if __name__ == "__main__":
    from default_simulation import simulate_defaults
    from portfolio import example_portfolio
    import numpy as np

    portfolio = example_portfolio()
    size = len(portfolio)
    corr_matrix = np.identity(size)

    defaults = simulate_defaults(portfolio, corr_matrix, num_simulations=1000)
    losses = calculate_loss(defaults, portfolio)
    print(f"Expected Loss (analytical): ${expected_loss(portfolio)/1e6:.2f}M")
    print(f"Simulated mean loss: ${np.mean(losses)/1e6:.2f}M")
