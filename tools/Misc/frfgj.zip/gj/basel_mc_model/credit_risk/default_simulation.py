"""
default_simulation.py

Monte Carlo simulation of correlated defaults using Gaussian copula method.

Author: Your Name
"""

import numpy as np
import scipy.stats as stats

def simulate_defaults(portfolio, corr_matrix, num_simulations=10000):
    """
    Simulates correlated defaults over multiple simulations.

    Args:
        portfolio: LoanPortfolio instance
        corr_matrix: numpy array of asset correlations
        num_simulations: int, number of Monte Carlo runs

    Returns:
        defaults: numpy bool array of shape (num_simulations, portfolio_size)
    """
    size = len(portfolio)
    cholesky = np.linalg.cholesky(corr_matrix)
    defaults = np.zeros((num_simulations, size), dtype=bool)

    for sim in range(num_simulations):
        independent_normals = np.random.randn(size)
        correlated_normals = cholesky @ independent_normals

        for i, loan in enumerate(portfolio.loans):
            threshold = stats.norm.ppf(loan.PD)
            defaults[sim, i] = correlated_normals[i] < threshold

    return defaults

if __name__ == "__main__":
    from portfolio import example_portfolio
    portfolio = example_portfolio()
    size = len(portfolio)
    corr_matrix = np.identity(size)
    defaults = simulate_defaults(portfolio, corr_matrix, num_simulations=5)
    print("Defaults matrix (True=default):")
    print(defaults)
