"""
macro_factors.py

Models macroeconomic variables (GDP, unemployment, interest rates) with simple time series.

Author: Your Name
"""

import numpy as np

class MacroFactors:
    def __init__(self, initial_gdp=1.0, initial_unemployment=0.05, initial_rate=0.03):
        self.gdp = initial_gdp
        self.unemployment = initial_unemployment
        self.interest_rate = initial_rate

    def step(self, shock_gdp=0.0, shock_unemployment=0.0, shock_rate=0.0):
        """
        Advance one time step with optional shocks.

        Shocks are fractional or absolute changes applied to variables.
        """
        # Simple AR(1) style dynamics with shocks
        self.gdp = max(0, self.gdp * (1 + shock_gdp))
        self.unemployment = min(1, max(0, self.unemployment + shock_unemployment))
        self.interest_rate = max(0, self.interest_rate + shock_rate)

    def get_state(self):
        return {
            "gdp": self.gdp,
            "unemployment": self.unemployment,
            "interest_rate": self.interest_rate
        }

if __name__ == "__main__":
    macro = MacroFactors()
    print("Initial macro state:", macro.get_state())
    macro.step(shock_gdp=-0.02, shock_unemployment=0.005, shock_rate=-0.001)
    print("After shock step:", macro.get_state())
