"""
stress_scenarios.py

Defines macroeconomic stress scenarios as sequences of shocks to macro factors.

Author: Your Name
"""

def ice_defiance_scenario(time_steps=12):
    """
    Example scenario: ICE defiance causes escalating economic stress over 12 months.
    Returns a list of dict shocks per step.
    """
    scenario = []
    for t in range(time_steps):
        # Increasing GDP decline and unemployment rise
        shock_gdp = -0.01 - 0.015 * t  # GDP drop increasing each step
        shock_unemployment = 0.002 + 0.003 * t
        shock_interest = -0.0005  # Slight easing
        scenario.append({
            "shock_gdp": shock_gdp,
            "shock_unemployment": shock_unemployment,
            "shock_interest_rate": shock_interest
        })
    return scenario

def mild_recession_scenario(time_steps=12):
    """
    Mild recession with moderate shocks.
    """
    scenario = []
    for t in range(time_steps):
        shock_gdp = -0.005
        shock_unemployment = 0.001
        shock_interest = 0.0
        scenario.append({
            "shock_gdp": shock_gdp,
            "shock_unemployment": shock_unemployment,
            "shock_interest_rate": shock_interest
        })
    return scenario

if __name__ == "__main__":
    print("ICE Defiance scenario shocks:")
    for step, shocks in enumerate(ice_defiance_scenario()):
        print(f"Month {step+1}: {shocks}")
