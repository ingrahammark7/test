"""
feedback_loops.py

Adjust credit risk parameters dynamically based on macroeconomic variables.

Author: Your Name
"""

def adjust_PD(base_PD, gdp, unemployment):
    """
    Adjust Probability of Default (PD) based on macro factors.
    Simple linear adjustment: PD increases as GDP falls and unemployment rises.

    Args:
        base_PD: float, base PD without stress
        gdp: float, normalized GDP (1.0 = baseline)
        unemployment: float, unemployment rate (0 to 1)

    Returns:
        adjusted_PD: float
    """
    # Increase PD when GDP below baseline or unemployment above baseline (~5%)
    gdp_factor = max(0, 1 - gdp) * 2  # Amplify effect
    unemp_factor = max(0, unemployment - 0.05) * 3

    adjusted = base_PD * (1 + gdp_factor + unemp_factor)
    return min(adjusted, 1.0)

def adjust_LGD(base_LGD, gdp):
    """
    Adjust LGD upwards when economy worsens.

    Args:
        base_LGD: float, base loss given default
        gdp: float, normalized GDP

    Returns:
        adjusted_LGD: float
    """
    lgd_increase = max(0, 1 - gdp) * 0.2  # Up to +20% LGD
    adjusted = base_LGD * (1 + lgd_increase)
    return min(adjusted, 1.0)

if __name__ == "__main__":
    base_PD = 0.02
    base_LGD = 0.45
    print("Base PD:", base_PD)
    print("Adjusted PD (GDP=0.9, Unemp=0.07):", adjust_PD(base_PD, 0.9, 0.07))
    print("Adjusted LGD (GDP=0.9):", adjust_LGD(base_LGD, 0.9))
