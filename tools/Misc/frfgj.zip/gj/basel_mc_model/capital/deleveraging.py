"""
deleveraging.py

Simulates deleveraging by adjusting exposures when capital ratio breaches occur.

Author: Your Name
"""

def apply_deleveraging(portfolio, current_ratio, min_ratio=0.08, deleveraging_rate=0.1):
    """
    Reduce exposures proportionally if capital ratio below minimum.

    Args:
        portfolio: LoanPortfolio instance
        current_ratio: float, current capital ratio
        min_ratio: float, minimum required capital ratio
        deleveraging_rate: float, fraction to reduce exposures per breach step

    Returns:
        updated_portfolio: LoanPortfolio with adjusted EADs
    """
    if current_ratio >= min_ratio:
        return portfolio  # No deleveraging needed

    reduction_factor = 1 - deleveraging_rate
    for loan in portfolio.loans:
        loan.EAD *= reduction_factor

    return portfolio

if __name__ == "__main__":
    from credit_risk.portfolio import example_portfolio
    portfolio = example_portfolio()
    print("Before deleveraging:")
    for loan in portfolio.loans:
        print(f"{loan.name}: EAD=${loan.EAD/1e9:.3f}B")

    current_ratio = 0.06  # Example below 8% minimum
    portfolio = apply_deleveraging(portfolio, current_ratio)

    print("\nAfter deleveraging:")
    for loan in portfolio.loans:
        print(f"{loan.name}: EAD=${loan.EAD/1e9:.3f}B")
