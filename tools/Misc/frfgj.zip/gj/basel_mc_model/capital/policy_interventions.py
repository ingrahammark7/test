"""
policy_interventions.py

Simulates regulatory or policy actions affecting capital and exposures.

Author: Your Name
"""

def apply_capital_injection(tier1_capital, injection_amount):
    """
    Increase Tier 1 capital by injection amount.

    Args:
        tier1_capital: float, current Tier 1 capital
        injection_amount: float, capital injected

    Returns:
        updated Tier 1 capital
    """
    return tier1_capital + injection_amount

def apply_exposure_limits(portfolio, max_exposure_per_loan):
    """
    Cap exposures in portfolio to a maximum amount.

    Args:
        portfolio: LoanPortfolio instance
        max_exposure_per_loan: float, max allowed EAD per loan

    Returns:
        portfolio with capped exposures
    """
    for loan in portfolio.loans:
        if loan.EAD > max_exposure_per_loan:
            loan.EAD = max_exposure_per_loan
    return portfolio

if __name__ == "__main__":
    from credit_risk.portfolio import example_portfolio
    portfolio = example_portfolio()
    tier1 = 100e9

    print(f"Initial Tier 1 Capital: ${tier1/1e9:.2f}B")
    tier1 = apply_capital_injection(tier1, 25e9)
    print(f"After capital injection: ${tier1/1e9:.2f}B")

    print("Before exposure limit:")
    for loan in portfolio.loans:
        print(f"{loan.name}: EAD=${loan.EAD/1e9:.2f}B")

    portfolio = apply_exposure_limits(portfolio, 3e9)

    print("After exposure limit:")
    for loan in portfolio.loans:
        print(f"{loan.name}: EAD=${loan.EAD/1e9:.2f}B")
