"""
capital_calculation.py

Calculates regulatory capital requirements, capital ratios, and buffers.

Author: Your Name
"""

def calculate_rwa(portfolio, risk_weights):
    """
    Calculate Risk Weighted Assets (RWA).

    Args:
        portfolio: list of LoanExposure objects (must have EAD attribute)
        risk_weights: list of floats, corresponding risk weights (0-1 scale)

    Returns:
        Total RWA (float)
    """
    total_rwa = 0
    for loan, rw in zip(portfolio.loans, risk_weights):
        total_rwa += loan.EAD * rw
    return total_rwa

def capital_ratio(tier1_capital, rwa):
    """
    Calculate Tier 1 Capital Ratio.

    Args:
        tier1_capital: float, regulatory Tier 1 capital
        rwa: float, risk weighted assets

    Returns:
        ratio (float)
    """
    if rwa == 0:
        return 0
    return tier1_capital / rwa

def check_minimum_capital(ratio, minimum=0.08):
    """
    Check if capital ratio meets minimum regulatory requirement.

    Args:
        ratio: float, capital ratio
        minimum: float, minimum required ratio (default 8%)

    Returns:
        bool: True if meets requirement, False otherwise
    """
    return ratio >= minimum

if __name__ == "__main__":
    from credit_risk.portfolio import example_portfolio
    from credit_risk.basel_irb import risk_weight_corporate

    portfolio = example_portfolio()
    risk_weights = [risk_weight_corporate(loan.PD, loan.LGD, loan.M) for loan in portfolio.loans]
    rwa = calculate_rwa(portfolio, risk_weights)
    tier1 = 150e9  # Example Tier 1 capital $150B
    ratio = capital_ratio(tier1, rwa)
    print(f"Total RWA: ${rwa/1e9:.2f}B")
    print(f"Tier 1 Capital Ratio: {ratio*100:.2f}%")
    print(f"Meets minimum requirement: {check_minimum_capital(ratio)}")
