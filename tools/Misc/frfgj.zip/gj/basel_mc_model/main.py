"""
main.py

Entrypoint to run Basel Monte Carlo integrated risk model.

Author: Your Name
"""

from simulation import monte_carlo_runner, results_aggregator
from reporting import dashboard, report_generator

def main():
    print("Starting Basel MC Model Simulation...\n")

    capital_ratios = monte_carlo_runner.run_simulation(num_simulations=5000, macro_steps=12)
    # For simplicity, create dummy losses array as placeholder
    import numpy as np
    losses = np.random.normal(1e9, 2e8, 5000)

    summary = results_aggregator.summarize_losses(losses)

    # Print textual report
    report = report_generator.generate_text_report(capital_ratios, summary)
    print(report)

    # Display dashboard with plots
    dashboard.display_dashboard(capital_ratios, losses)

if __name__ == "__main__":
    main()
