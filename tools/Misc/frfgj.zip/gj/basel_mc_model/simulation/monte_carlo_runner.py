"""
monte_carlo_runner.py

Runs the full Monte Carlo simulation integrating portfolio, default simulation,
loss calculation, capital calculation, and macro feedback loops.

Author: Your Name
"""

import numpy as np
from credit_risk import portfolio, default_simulation, loss_calculation
from macro import macro_factors, feedback_loops
from capital import capital_calculation, deleveraging, policy_interventions

def run_simulation(num_simulations=10000, macro_steps=12):
    # Initialize portfolio
    port = portfolio.example_portfolio()

    # Initialize macro factors
    macro = macro_factors.MacroFactors()

    # Initialize Tier 1 capital (example)
    tier1_capital = 150e9

    # Store capital ratios over time
    capital_ratios = []

    # Simple identity correlation matrix for example
    size = len(port)
    corr_matrix = np.identity(size)

    for step in range(macro_steps):
        state = macro.get_state()
        # Adjust PD and LGD based on macro feedback
        adjusted_loans = []
        for loan in port.loans:
            adj_PD = feedback_loops.adjust_PD(loan.PD, state["gdp"], state["unemployment"])
            adj_LGD = feedback_loops.adjust_LGD(loan.LGD, state["gdp"])
            adjusted_loans.append(portfolio.LoanExposure(loan.name, loan.EAD, adj_PD, adj_LGD, loan.M))
        # Create adjusted portfolio
        adjusted_port = portfolio.LoanPortfolio(adjusted_loans)

        # Run defaults simulation
        defaults = default_simulation.simulate_defaults(adjusted_port, corr_matrix, num_simulations)

        # Calculate losses
        losses = loss_calculation.calculate_loss(defaults, adjusted_port)
        avg_loss = np.mean(losses)

        # Calculate risk weights
        risk_weights = []
        from credit_risk.basel_irb import risk_weight_corporate
        for loan in adjusted_port.loans:
            risk_weights.append(risk_weight_corporate(loan.PD, loan.LGD, loan.M))

        # Calculate RWA and capital ratio
        rwa = capital_calculation.calculate_rwa(adjusted_port, risk_weights)
        ratio = capital_calculation.capital_ratio(tier1_capital, rwa)

        capital_ratios.append(ratio)

        # Apply deleveraging if needed
        port = deleveraging.apply_deleveraging(port, ratio)

        # Step macro forward without shocks for simplicity
        macro.step()

    return capital_ratios

if __name__ == "__main__":
    ratios = run_simulation(1000, 6)
    for i, r in enumerate(ratios, 1):
        print(f"Month {i}: Capital Ratio = {r*100:.2f}%")
