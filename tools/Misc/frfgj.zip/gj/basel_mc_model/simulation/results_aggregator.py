"""
results_aggregator.py

Aggregates simulation results to generate statistics and summary metrics.

Author: Your Name
"""

import numpy as np

def summarize_losses(losses):
    """
    Summarizes losses array (simulations x time steps or total).

    Returns mean, median, 99th percentile, and max loss.
    """
    mean_loss = np.mean(losses)
    median_loss = np.median(losses)
    percentile_99 = np.percentile(losses, 99)
    max_loss = np.max(losses)

    return {
        "mean_loss": mean_loss,
        "median_loss": median_loss,
        "99th_percentile_loss": percentile_99,
        "max_loss": max_loss
    }

if __name__ == "__main__":
    # Demo with synthetic data
    np.random.seed(0)
    losses = np.random.normal(loc=1e9, scale=2e8, size=10000)
    summary = summarize_losses(losses)
    for k, v in summary.items():
        print(f"{k}: ${v/1e6:.2f}M")
