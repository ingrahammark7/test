"""
scenario_manager.py

Manages stress scenarios and applies macro shocks to macro factors.

Author: Your Name
"""

from macro import macro_factors, stress_scenarios

class ScenarioManager:
    def __init__(self, macro_model):
        self.macro = macro_model
        self.scenario = []
        self.current_step = 0

    def load_scenario(self, scenario_name):
        if scenario_name == "ice_defiance":
            self.scenario = stress_scenarios.ice_defiance_scenario()
        elif scenario_name == "mild_recession":
            self.scenario = stress_scenarios.mild_recession_scenario()
        else:
            self.scenario = []

    def step(self):
        if self.current_step < len(self.scenario):
            shocks = self.scenario[self.current_step]
            self.macro.step(
                shock_gdp=shocks.get("shock_gdp", 0.0),
                shock_unemployment=shocks.get("shock_unemployment", 0.0),
                shock_rate=shocks.get("shock_interest_rate", 0.0),
            )
            self.current_step += 1
        else:
            # No shocks; normal step
            self.macro.step()

if __name__ == "__main__":
    macro = macro_factors.MacroFactors()
    manager = ScenarioManager(macro)
    manager.load_scenario("ice_defiance")
    for i in range(5):
        manager.step()
        print(f"Step {i+1} Macro state: {macro.get_state()}")
