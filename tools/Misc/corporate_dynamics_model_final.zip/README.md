# Corporate Dynamics Model

A simulation of firm behavior in economic ecosystems.