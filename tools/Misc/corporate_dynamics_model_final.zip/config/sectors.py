sectors = {
    'Information Technology': {
        'weight': 0.27, 'base_decay': 0.06, 'reg_risk': 0.03, 'tech_adapt': 0.4, 'merger_base': 0.04,
        'avg_comp_pos': 0.75, 'avg_debt_ratio': 1.0, 'reg_shock_freq': 0.05, 'ipo_rate': 0.015,
        'shock_scenarios': ['regulatory', 'tech_disruption']
    },
    'Health Care': {
        'weight': 0.14, 'base_decay': 0.03, 'reg_risk': 0.05, 'tech_adapt': 0.7, 'merger_base': 0.02,
        'avg_comp_pos': 0.8, 'avg_debt_ratio': 0.8, 'reg_shock_freq': 0.04, 'ipo_rate': 0.01,
        'shock_scenarios': ['regulatory']
    },
    'Financials': {
        'weight': 0.14, 'base_decay': 0.02, 'reg_risk': 0.07, 'tech_adapt': 0.6, 'merger_base': 0.03,
        'avg_comp_pos': 0.7, 'avg_debt_ratio': 1.5, 'reg_shock_freq': 0.06, 'ipo_rate': 0.01,
        'shock_scenarios': ['regulatory', 'financial_crisis']
    },
    'Consumer Discretionary': {
        'weight': 0.11, 'base_decay': 0.04, 'reg_risk': 0.04, 'tech_adapt': 0.5, 'merger_base': 0.025,
        'avg_comp_pos': 0.7, 'avg_debt_ratio': 1.0, 'reg_shock_freq': 0.04, 'ipo_rate': 0.012,
        'shock_scenarios': ['regulatory']
    },
    'Communication Services': {
        'weight': 0.08, 'base_decay': 0.05, 'reg_risk': 0.03, 'tech_adapt': 0.45, 'merger_base': 0.035,
        'avg_comp_pos': 0.65, 'avg_debt_ratio': 1.1, 'reg_shock_freq': 0.03, 'ipo_rate': 0.01,
        'shock_scenarios': ['tech_disruption']
    },
    'Industrials': {
        'weight': 0.08, 'base_decay': 0.03, 'reg_risk': 0.04, 'tech_adapt': 0.55, 'merger_base': 0.02,
        'avg_comp_pos': 0.7, 'avg_debt_ratio': 1.2, 'reg_shock_freq': 0.04, 'ipo_rate': 0.01,
        'shock_scenarios': []
    },
    'Consumer Staples': {
        'weight': 0.07, 'base_decay': 0.015, 'reg_risk': 0.05, 'tech_adapt': 0.8, 'merger_base': 0.015,
        'avg_comp_pos': 0.85, 'avg_debt_ratio': 0.6, 'reg_shock_freq': 0.03, 'ipo_rate': 0.008,
        'shock_scenarios': []
    },
    'Energy': {
        'weight': 0.03, 'base_decay': 0.04, 'reg_risk': 0.05, 'tech_adapt': 0.3, 'merger_base': 0.03,
        'avg_comp_pos': 0.6, 'avg_debt_ratio': 1.3, 'reg_shock_freq': 0.05, 'ipo_rate': 0.005,
        'shock_scenarios': ['commodity_price_shock']
    },
    'Utilities': {
        'weight': 0.02, 'base_decay': 0.01, 'reg_risk': 0.06, 'tech_adapt': 0.7, 'merger_base': 0.01,
        'avg_comp_pos': 0.9, 'avg_debt_ratio': 0.5, 'reg_shock_freq': 0.04, 'ipo_rate': 0.004,
        'shock_scenarios': []
    },
    'Materials': {
        'weight': 0.02, 'base_decay': 0.025, 'reg_risk': 0.04, 'tech_adapt': 0.6, 'merger_base': 0.02,
        'avg_comp_pos': 0.7, 'avg_debt_ratio': 1.0, 'reg_shock_freq': 0.04, 'ipo_rate': 0.005,
        'shock_scenarios': ['commodity_price_shock']
    },
    'Real Estate': {
        'weight': 0.02, 'base_decay': 0.02, 'reg_risk': 0.05, 'tech_adapt': 0.7, 'merger_base': 0.01,
        'avg_comp_pos': 0.75, 'avg_debt_ratio': 1.1, 'reg_shock_freq': 0.04, 'ipo_rate': 0.006,
        'shock_scenarios': []
    },
}
