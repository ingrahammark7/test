import matplotlib.pyplot as plt
from config.sectors import sectors

def plot_results(record):
    plt.figure(figsize=(16, 6))
    for s in sectors:
        plt.plot(record[f'{s}_count'], label=s)
    plt.title('Alive Firm Count per Sector')
    plt.legend(fontsize='small')
    plt.grid(True)
    plt.show()
