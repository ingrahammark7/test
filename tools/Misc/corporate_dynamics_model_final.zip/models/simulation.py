import numpy as np
from collections import defaultdict
from config.sectors import sectors
from models.firm import create_firm, apply_losses, firm_failed
from models.economy import economic_cycle, generate_shocks

TOTAL_FIRMS = 1000

def initialize_firms():
    firms = []
    for sector, p in sectors.items():
        n = int(p['weight'] * TOTAL_FIRMS)
        firms += [create_firm(sector) for _ in range(n)]
    return firms

def simulate_year(firms, year):
    E = economic_cycle(year)
    shocks = generate_shocks(year, E)

    alive = [f for f in firms if f['alive']]
    np.random.shuffle(alive)

    for f in alive:
        apply_losses(f, shocks, E)
        if firm_failed(f):
            f['alive'] = False

    # Mergers
    alive = [f for f in firms if f['alive']]
    np.random.shuffle(alive)
    for acq in alive:
        if np.random.rand() < acq['merger_base'] * acq['S'] * acq['size']:
            targets = [f for f in alive if f != acq and f['S'] < 0.8]
            if targets:
                t = targets[np.random.randint(len(targets))]
                acq['size'] += t['size'] * 0.7
                acq['S'] += t['S'] * 0.5
                t['alive'] = False

    # IPOs
    for sector, p in sectors.items():
        count = len([f for f in firms if f['alive'] and f['sector'] == sector])
        new = int(count * p['ipo_rate'])
        for _ in range(new):
            firms.append(create_firm(sector))

    return firms

def run_simulation(years=50):
    firms = initialize_firms()
    record = defaultdict(list)

    for year in range(years):
        firms = simulate_year(firms, year)
        counts = defaultdict(int)
        avgS = defaultdict(list)
        avgSize = defaultdict(list)

        for f in firms:
            if f['alive']:
                counts[f['sector']] += 1
                avgS[f['sector']].append(f['S'])
                avgSize[f['sector']].append(f['size'])

        for s in sectors:
            record[f'{s}_count'].append(counts[s])
            record[f'{s}_avgS'].append(np.mean(avgS[s]) if avgS[s] else 0)
            record[f'{s}_avgSize'].append(np.mean(avgSize[s]) if avgSize[s] else 0)

    return record
