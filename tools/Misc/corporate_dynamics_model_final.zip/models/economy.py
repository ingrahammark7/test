import numpy as np
from collections import defaultdict
from config.sectors import sectors

def economic_cycle(t, period=8, noise_std=0.1):
    base = np.sin(2 * np.pi * t / period)
    noise = np.random.normal(0, noise_std)
    return np.clip(base + noise, -1, 1)

def generate_shocks(year, econ_signal):
    sector_shocks = defaultdict(lambda: False)
    for sector, p in sectors.items():
        if 'regulatory' in p['shock_scenarios']:
            if np.random.rand() < p['reg_shock_freq'] * (1 + max(0, -econ_signal)):
                sector_shocks[sector + '_regulatory'] = True
        if 'tech_disruption' in p['shock_scenarios']:
            if np.random.rand() < 0.1:
                sector_shocks[sector + '_tech'] = True
        if 'commodity_price_shock' in p['shock_scenarios']:
            if np.random.rand() < 0.05:
                sector_shocks[sector + '_commodity'] = True
        if 'financial_crisis' in p['shock_scenarios']:
            if np.random.rand() < 0.03:
                sector_shocks[sector + '_financial_crisis'] = True
    return sector_shocks
