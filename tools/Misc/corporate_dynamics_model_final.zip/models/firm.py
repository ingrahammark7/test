import numpy as np
from config.sectors import sectors

FAIL_THRESHOLD = 0.1
DEBT_FAIL_THRESHOLD = 2.0
DEBT_FAIL_PROB = 0.1
STRATEGIC_ERROR_PROB = 0.02
STRATEGIC_ERROR_SEVERITY = 0.15
ALPHA_SIZE_FAIL = 0.5

def create_firm(sector):
    p = sectors[sector]
    return {
        'sector': sector,
        'S': 1.0,
        'size': np.random.uniform(0.8, 1.2),
        'C': np.clip(np.random.normal(p['avg_comp_pos'], 0.1), 0.3, 1.0),
        'D': np.clip(np.random.normal(p['avg_debt_ratio'], 0.5), 0.0, 3.0),
        'R': p['reg_risk'],
        'T': p['tech_adapt'],
        'merger_base': p['merger_base'],
        'alive': True
    }

def apply_losses(f, shocks, econ_signal):
    from models.shocks import REG_SHOCK_SEVERITY, TECH_DISRUPTION_SEVERITY,                                COMMODITY_SHOCK_SEVERITY, FINANCIAL_CRISIS_SEVERITY

    p = sectors[f['sector']]
    f['S'] -= f['S'] * p['base_decay'] * (1 - f['C']) * (1 + 0.5 * (-econ_signal))
    if shocks.get(f['sector'] + '_regulatory', False):
        f['S'] -= f['S'] * REG_SHOCK_SEVERITY
    if shocks.get(f['sector'] + '_tech', False) and f['T'] < 0.5:
        f['S'] -= f['S'] * TECH_DISRUPTION_SEVERITY
    if shocks.get(f['sector'] + '_commodity', False):
        f['S'] -= f['S'] * COMMODITY_SHOCK_SEVERITY
    if shocks.get(f['sector'] + '_financial_crisis', False):
        f['S'] -= f['S'] * FINANCIAL_CRISIS_SEVERITY
    if np.random.rand() < STRATEGIC_ERROR_PROB:
        f['S'] -= f['S'] * STRATEGIC_ERROR_SEVERITY

def firm_failed(f):
    if not f['alive']:
        return True
    if f['S'] < FAIL_THRESHOLD:
        return True
    if f['D'] > DEBT_FAIL_THRESHOLD:
        prob = DEBT_FAIL_PROB / (f['size'] ** ALPHA_SIZE_FAIL)
        if np.random.rand() < prob:
            return True
    return False
