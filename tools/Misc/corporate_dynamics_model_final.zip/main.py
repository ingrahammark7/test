# Entry point
from models.simulation import run_simulation
from utils.plotting import plot_results

record = run_simulation(50)
plot_results(record)