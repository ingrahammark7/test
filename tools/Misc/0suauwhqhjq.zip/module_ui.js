/* Module 9: ui.js
   User interface and integration layer
*/

export function initUI() {
  // Stub: create a simple button to re-run demo on page
  const btn = document.createElement('button');
  btn.textContent = 'Run Demo Again';
  btn.style.margin = '1rem 0';
  btn.onclick = () => {
    alert('Demo rerun requested — implement as needed.');
  };
  document.body.appendChild(btn);
}

