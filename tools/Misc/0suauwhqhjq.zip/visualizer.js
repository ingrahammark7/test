export class Visualizer {
  constructor(canvasId) {
    this.canvas = document.getElementById(canvasId);
    this.ctx = this.canvas.getContext('2d');
    this.width = this.canvas.width;
    this.height = this.canvas.height;
    this.centerX = this.width / 2;
    this.centerY = this.height / 2;
  }

  clear() {
    this.ctx.fillStyle = '#000';
    this.ctx.fillRect(0, 0, this.width, this.height);
  }

  drawElectron(electron) {
    const x = this.centerX + electron.position.x;
    const y = this.centerY + electron.position.y;
    this.ctx.beginPath();
    this.ctx.arc(x, y, 5, 0, Math.PI * 2);
    this.ctx.fillStyle = 'cyan';
    this.ctx.fill();
  }

  drawOrbit(orbital) {
    this.ctx.strokeStyle = 'lime';
    this.ctx.beginPath();
    this.ctx.arc(this.centerX, this.centerY, orbital.n * 20, 0, Math.PI * 2);
    this.ctx.stroke();
  }

  render(orbitals) {
    this.clear();
    for (const orbital of orbitals) {
      this.drawOrbit(orbital);
      for (const electron of orbital.electrons) {
        this.drawElectron(electron);
      }
    }
  }
}
