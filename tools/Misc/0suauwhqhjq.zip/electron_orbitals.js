export class Electron {
  constructor(energyLevel = 1) {
    this.energyLevel = energyLevel;
    this.position = { x: 0, y: 0 };
    this.angle = Math.random() * Math.PI * 2;
    this.orbitRadius = 20 * energyLevel;
    this.angularVelocity = 0.05 / energyLevel;
  }

  tick(dt = 1) {
    this.angle += this.angularVelocity * dt;
    this.position.x = this.orbitRadius * Math.cos(this.angle);
    this.position.y = this.orbitRadius * Math.sin(this.angle);
  }

  getEnergy() {
    return -13.6 / (this.energyLevel ** 2); // Hydrogen-like energy
  }
}

export class Orbital {
  constructor(n = 1) {
    this.n = n;
    this.electrons = [];
  }

  addElectron() {
    if (this.electrons.length < 2 * this.n ** 2) {
      this.electrons.push(new Electron(this.n));
    }
  }

  tick(dt = 1) {
    for (const e of this.electrons) {
      e.tick(dt);
    }
  }
}
