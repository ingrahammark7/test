/* Module 5: decay.js
   Beta decay half-life and decay chain simulations
*/

export function betaDecayHalfLife(Z, N) {
  // Rough QRPA-inspired beta decay half-life estimate (seconds)
  const Qbeta = 15 - 0.1 * (N - Z); // MeV energy window approx
  if (Qbeta <= 0) return Infinity; // stable
  return Math.exp(5 / Qbeta); // exponential scaling
}

export function simulateDecayChain(Z, N, steps=5) {
  // Simulate a simple decay chain by incrementing N until stable
  let chain = [{Z, N}];
  for(let i=0; i<steps; i++) {
    if (N <= Z) break; // assume stable if N<=Z
    N -= 1; // beta decay neutron->proton
    Z += 1;
    chain.push({Z, N});
  }
  return chain;
}
,
