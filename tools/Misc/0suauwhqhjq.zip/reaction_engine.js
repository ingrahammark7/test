export class ReactionEngine {
  constructor() {
    this.fissionProbability = 1e-3; // realistic per tick
    this.fusionProbability = 1e-4;
    this.decayProbability = 1e-5;
  }

  attemptFission(nucleus) {
    if (nucleus.A > 200 && Math.random() < this.fissionProbability) {
      const A1 = Math.floor(nucleus.A / 2);
      const A2 = nucleus.A - A1;
      const daughter1 = { Z: Math.floor(nucleus.Z / 2), N: A1 - Math.floor(nucleus.Z / 2), A: A1 };
      const daughter2 = { Z: nucleus.Z - daughter1.Z, N: A2 - (nucleus.Z - daughter1.Z), A: A2 };
      return [daughter1, daughter2];
    }
    return null;
  }

  attemptFusion(nucleus1, nucleus2) {
    if (nucleus1.A < 20 && nucleus2.A < 20 && Math.random() < this.fusionProbability) {
      const fused = {
        Z: nucleus1.Z + nucleus2.Z,
        N: nucleus1.N + nucleus2.N,
        A: nucleus1.A + nucleus2.A
      };
      return fused;
    }
    return null;
  }

  attemptDecay(nucleus) {
    if (Math.random() < this.decayProbability) {
      // Simplified alpha decay for heavy nuclei
      if (nucleus.Z > 82 && nucleus.N > 2) {
        const daughter = { Z: nucleus.Z - 2, N: nucleus.N - 2, A: nucleus.A - 4 };
        return { type: 'alpha', daughter };
      }
    }
    return null;
  }
}
