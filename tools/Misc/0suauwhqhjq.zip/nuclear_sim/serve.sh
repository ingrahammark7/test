#!/bin/bash
echo "🌐 Serving on http://localhost:8000"
python3 -m http.server
