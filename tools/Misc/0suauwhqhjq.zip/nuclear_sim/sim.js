const out = document.getElementById('output');

function log(msg) {
  out.textContent += "\n" + msg;
  out.scrollTop = out.scrollHeight;
}

function randn(mean, stddev) {
  let u1 = Math.random();
  let u2 = Math.random();
  let z = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
  return mean + stddev * z;
}

function simulate() {
  log("🔬 Nuclear decay simulation started...");

  const particles = Array.from({ length: 1000 }, (_, i) => ({
    id: i,
    halfLife: randn(30, 5),  // fake units
    age: 0,
    decayed: false
  }));

  let ticks = 0;
  const maxTicks = 100;

  function tick() {
    ticks++;
    let decayedThisTick = 0;
    for (let p of particles) {
      if (p.decayed) continue;
      p.age++;
      if (Math.random() < 0.01 * Math.exp(-p.age / p.halfLife)) {
        p.decayed = true;
        decayedThisTick++;
      }
    }
    log(`Tick ${ticks}: ${decayedThisTick} decayed`);

    if (ticks < maxTicks) {
      setTimeout(tick, 100);
    } else {
      log("✅ Simulation complete.");
    }
  }

  tick();
}

// FORCE RUN ON LOAD
window.onload = simulate;
