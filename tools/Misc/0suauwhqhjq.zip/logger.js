export class Logger {
  constructor(logElementId) {
    this.logElement = document.getElementById(logElementId);
    this.logs = [];
    this.filters = new Set(); // event types to show; empty means show all
  }

  log(eventType, message) {
    const timestamp = new Date().toISOString();
    const logEntry = { timestamp, eventType, message };
    this.logs.push(logEntry);
    if (this.filters.size === 0 || this.filters.has(eventType)) {
      this._renderLog(logEntry);
    }
  }

  _renderLog({ timestamp, eventType, message }) {
    const entry = document.createElement('div');
    entry.textContent = `[${timestamp}] (${eventType}) ${message}`;
    this.logElement.appendChild(entry);
    this.logElement.scrollTop = this.logElement.scrollHeight;
  }

  setFilter(eventTypes) {
    this.filters = new Set(eventTypes);
    this.logElement.innerHTML = '';
    for (const logEntry of this.logs) {
      if (this.filters.size === 0 || this.filters.has(logEntry.eventType)) {
        this._renderLog(logEntry);
      }
    }
  }

  clear() {
    this.logs = [];
    this.logElement.innerHTML = '';
  }
}
