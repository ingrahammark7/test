// qrpa.js: Toy QRPA collective excitations as harmonic oscillator modes

export function qrpaExcitations(shellsCount) {
  // Generate toy collective excitation energies and strengths
  // energies in MeV, strengths arbitrary units
  let modes = [];
  for(let i=1; i<=shellsCount; i++) {
    const energy = 1.0 + i * 0.5;   // increasing energy
    const strength = Math.exp(-0.1 * i); // decaying strength
    modes.push({mode: i, energy, strength});
  }
  return modes;
}
