/*
 * Tracks simplified quantum entanglement pairs between particles.
 * Each pair has an entanglement strength that decays over time.
 */

export class EntanglementTracker {
  constructor() {
    this.pairs = new Map(); // key: 'id1-id2', value: {strength, particles}
  }

  entangle(p1, p2) {
    const key = [p1.id, p2.id].sort().join('-');
    this.pairs.set(key, { strength: 1.0, particles: [p1, p2] });
  }

  decay(dt) {
    for (const [key, pair] of this.pairs) {
      pair.strength -= 0.01 * dt;
      if (pair.strength <= 0) this.pairs.delete(key);
    }
  }

  getEntangledPairs() {
    return Array.from(this.pairs.values()).filter(p => p.strength > 0);
  }
}
