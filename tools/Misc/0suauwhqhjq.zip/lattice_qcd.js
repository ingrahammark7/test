// Lattice QCD simulation (toy model)
const gridSize = 32;
let lattice = Array.from({ length: gridSize }, () =>
  Array.from({ length: gridSize }, () =>
    Array.from({ length: gridSize }, () => Math.random() * 2 - 1)
  )
);

function iterateLattice() {
  for (let x = 1; x < gridSize - 1; x++) {
    for (let y = 1; y < gridSize - 1; y++) {
      for (let z = 1; z < gridSize - 1; z++) {
        const avg = (
          lattice[x-1][y][z] + lattice[x+1][y][z] +
          lattice[x][y-1][z] + lattice[x][y+1][z] +
          lattice[x][y][z-1] + lattice[x][y][z+1]
        ) / 6;
        lattice[x][y][z] = 0.99 * lattice[x][y][z] + 0.01 * avg;
      }
    }
  }
}

export { iterateLattice };
