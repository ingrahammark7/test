// physics.js: Core nuclear physics utility functions

export function woodsSaxonPotential(r, R, a, V0) {
  return -V0 / (1 + Math.exp((r - R) / a));
}

export function spinOrbitPotential(r, R, a, Vso, l, s) {
  const expTerm = Math.exp((r - R) / a);
  const dVdr = (Vso / a) * expTerm / ((1 + expTerm) ** 2);
  const ls = (l > 0) ? (0.5) * (1 / r) * dVdr : 0;
  return ls * s;
}

export function totalPotential(r, R, a, V0, Vso, l, s) {
  return woodsSaxonPotential(r, R, a, V0) + spinOrbitPotential(r, R, a, Vso, l, s);
}

export const shells = [
  {n:1,l:0,j:0.5,deg:2},  
  {n:1,l:1,j:1.5,deg:4},  
  {n:1,l:1,j:0.5,deg:2},  
  {n:1,l:2,j:2.5,deg:6},  
  {n:1,l:2,j:1.5,deg:4},  
  {n:2,l:0,j:0.5,deg:2},  
  {n:1,l:3,j:3.5,deg:8},  
  {n:1,l:3,j:2.5,deg:6},  
  {n:1,l:4,j:4.5,deg:10}, 
  {n:1,l:4,j:3.5,deg:8},  
];

export function shellEnergies() {
  let E0 = -40;
  let energies = [];
  for(let i=0; i<shells.length; i++) {
    let baseE = E0 + i * 5;
    let soSplit = (shells[i].j > shells[i].l) ? -2 : 2;
    energies.push(baseE + soSplit);
  }
  return energies;
}

export function fillShells(nucleonCount) {
  const energies = shellEnergies();
  let filled = 0;
  let magicNumbers = [];
  for(let i=0; i<energies.length; i++) {
    filled += shells[i].deg;
    if (filled >= nucleonCount) break;
    magicNumbers.push(filled);
  }
  return magicNumbers;
}

export function pairingGap(A) {
  if (A <= 0) return 0;
  return 12 / Math.sqrt(A);
}

export function skyrmeEnergyDensity(Z, N) {
  const A = Z + N;
  const r0 = 1.2;
  const R = r0 * Math.cbrt(A);
  const volume = (4/3) * Math.PI * Math.pow(R,3);
  const rho = A / volume;
  const t0 = -1800; // MeV fm^3
  return t0 * rho * rho;
}
