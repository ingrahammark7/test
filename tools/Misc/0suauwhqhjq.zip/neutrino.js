// neutrino.js: Toy neutrino-nucleus cross-section calculations

export function neutrinoCrossSection(E_nu) {
  // Toy model: cross-section ~ (E_nu - threshold)^2 if above threshold
  const threshold = 5; // MeV
  if(E_nu <= threshold) return 0;
  const sigma0 = 1e-42; // cm^2 baseline scale
  return sigma0 * (E_nu - threshold) * (E_nu - threshold);
}

export function neutrinoInteractionRates(energies) {
  return energies.map(E => ({E, sigma: neutrinoCrossSection(E)}));
}
