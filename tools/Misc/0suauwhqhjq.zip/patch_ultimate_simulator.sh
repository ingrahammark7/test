#!/bin/bash

echo "Patching ultimate_simulator.js to add safe .map() usage and debug logs..."

cat > ultimate_simulator.js << 'EOM'
import { MatterFactory } from './matter_factory.js';
import { Visualizer } from './visualizer.js';
import { Logger } from './logger.js';
import { UIControls } from './ui_controls.js';
import { ReactionEngine } from './reaction_engine.js';
import { HartreeFock } from './hartree_fock.js';
import { EntanglementTracker } from './entanglement.js';
import { VacuumFluctuations } from './vacuum_fluctuations.js';
import { relativisticMass, correctedDecayRate } from './relativistic_corrections.js';
import { AIOptimizer } from './ai_optimizer.js';

class UltimateSimulator {
  constructor(canvasId, logId, uiContainer) {
    this.logger = new Logger(logId);
    this.visualizer = new Visualizer(canvasId);
    this.factory = new MatterFactory();
    this.reactionEngine = new ReactionEngine();
    this.entanglement = new EntanglementTracker();
    this.vacuum = new VacuumFluctuations(1e-14);
    this.optimizer = new AIOptimizer(20, this.fitnessFunction.bind(this));

    this.uiControls = new UIControls(this.handleUIChange.bind(this));
    this.uiControls.attachTo(uiContainer);

    this.atom = this.factory.createAtom(92, 146);
    const electrons = (this.atom && Array.isArray(this.atom.orbitals)) 
      ? this.atom.orbitals.flatMap(o => o.electrons || []) 
      : [];
    if (electrons.length === 0) {
      console.warn('Warning: electrons array is empty or orbitals undefined', this.atom);
    }
    this.hfSolver = new HartreeFock(electrons);
    this.simSpeed = 100;

    this.lastTick = 0;
    this.optimizer.initialize({ Z: 92, N: 146 });

    this.logger.log('info', 'Ultimate Simulator initialized');
  }

  fitnessFunction(config) {
    const be = this.factory.estimateBindingEnergy(config.Z, config.N);
    return be || 0;
  }

  handleUIChange(data) {
    if (data.reset) {
      this.atom = this.factory.createAtom(parseInt(data.atomicNumber), parseInt(data.neutronNumber));
      const electrons = (this.atom && Array.isArray(this.atom.orbitals)) 
        ? this.atom.orbitals.flatMap(o => o.electrons || []) 
        : [];
      if (electrons.length === 0) {
        console.warn('Warning: electrons array is empty or orbitals undefined', this.atom);
      }
      this.hfSolver = new HartreeFock(electrons);
      this.logger.log('info', `Reset atom to Z=${data.atomicNumber}, N=${data.neutronNumber}`);
    }
    this.simSpeed = parseInt(data.speed);
  }

  simulateTick(delta) {
    this.vacuum.tick();
    this.hfSolver.iterate();
    this.entanglement.decay(delta / 1000);

    const decay = this.reactionEngine.attemptDecay(this.atom.nucleus);
    if (decay) {
      this.logger.log('decay', `Decay: ${decay.type}, daughter Z=${decay.daughter.Z}, N=${decay.daughter.N}`);
      this.atom = this.factory.createAtom(decay.daughter.Z, decay.daughter.N);
    }

    if (performance.now() % 10000 < delta) {
      this.optimizer.evolve();
      const best = this.optimizer.population[0];
      this.logger.log('ai', `AI best config: Z=${best.Z}, N=${best.N}, fitness=${this.fitnessFunction(best).toFixed(2)}`);
    }

    if (!this.atom.orbitals || !Array.isArray(this.atom.orbitals)) {
      console.warn('Warning: this.atom.orbitals undefined or not array', this.atom);
      return;
    }

    for (const orbital of this.atom.orbitals) {
      if (orbital && typeof orbital.tick === 'function') {
        orbital.tick();
      } else {
        console.warn('Warning: orbital missing or tick function undefined', orbital);
      }
    }
    this.visualizer.render(this.atom.orbitals);
  }

  run(timestamp) {
    if (!this.lastTick) this.lastTick = timestamp;
    const delta = timestamp - this.lastTick;
    console.log('Animation frame tick, delta:', delta);
    try {
      if (delta >= this.simSpeed) {
        this.simulateTick(delta);
        this.lastTick = timestamp;
      }
    } catch (e) {
      console.error('Simulation tick error:', e);
      this.logger.log('error', 'Simulation tick error: ' + e.message);
    }
    requestAnimationFrame(this.run.bind(this));
  }
}

export default UltimateSimulator;
EOM

chmod +x ultimate_simulator.js

echo "Patched ultimate_simulator.js with safe .map() usage and debug logs."
