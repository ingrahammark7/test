import { MatterFactory } from './matter_factory.js';
import { Visualizer } from './visualizer.js';

const logDiv = document.getElementById('log');
const log = (msg) => {
  logDiv.textContent += '\\n' + msg;
  logDiv.scrollTop = logDiv.scrollHeight;
};

const factory = new MatterFactory();
const visualizer = new Visualizer('orbitalCanvas');

// Create an atom: Uranium-238 (Z=92, N=146)
const atom = factory.createAtom(92, 146);

log('Created atom with Z=' + atom.nucleus.Z + ', N=' + atom.nucleus.N);

function tick() {
  // Update orbitals
  for (const orbital of atom.orbitals) {
    orbital.tick();
  }
  visualizer.render(atom.orbitals);

  // Log a simple message each tick (for demo)
  log('Tick: ' + new Date().toLocaleTimeString());

  requestAnimationFrame(tick);
}

// Start simulation loop
tick();
