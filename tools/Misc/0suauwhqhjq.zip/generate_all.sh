export class VacuumFluctuations {
  constructor(volumeSize) {
    this.volumeSize = volumeSize;
    this.virtualParticles = [];
  }

  tick() {
    if (Math.random() < 0.1) {
      this.virtualParticles.push({
        id: Date.now() + Math.random(),
        lifetime: 5,
        position: {
          x: (Math.random() - 0.5) * this.volumeSize,
          y: (Math.random() - 0.5) * this.volumeSize
        }
      });
    }
    this.virtualParticles = this.virtualParticles.filter(p => {
      p.lifetime -= 1;
      return p.lifetime > 0;
    });
  }
}
