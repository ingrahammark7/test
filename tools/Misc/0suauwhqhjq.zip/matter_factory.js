import { QuantumStates } from './quantum_states.js';
import { Orbital, Electron } from './electron_orbitals.js';

export class MatterFactory {
  constructor() {
    this.quantumStates = new QuantumStates();
  }

  createNucleus(Z, N) {
    return {
      Z: Z,
      N: N,
      A: Z + N,
      bindingEnergyPerNucleon: this.estimateBindingEnergy(Z, N),
      halfLife: this.estimateHalfLife(Z, N),
      decayModes: this.estimateDecayModes(Z, N)
    };
  }

  createAtom(Z, N) {
    const nucleus = this.createNucleus(Z, N);
    const atom = { nucleus, orbitals: [] };

    let remainingElectrons = Z;
    let n = 1;
    while (remainingElectrons > 0) {
      const orbital = new Orbital(n);
      while (orbital.electrons.length < 2 * n * n && remainingElectrons > 0) {
        orbital.addElectron();
        remainingElectrons--;
      }
      atom.orbitals.push(orbital);
      n++;
    }

    return atom;
  }

  estimateBindingEnergy(Z, N) {
    // Simplified semi-empirical mass formula (in MeV)
    const A = Z + N;
    const a_v = 15.75, a_s = 17.8, a_c = 0.711, a_a = 23.7, a_p = 12.0;
    const volume = a_v * A;
    const surface = a_s * Math.pow(A, 2/3);
    const coulomb = a_c * Z * (Z - 1) / Math.pow(A, 1/3);
    const asymmetry = a_a * ((N - Z) * (N - Z)) / A;
    const pairing = (Z % 2 === 0 && N % 2 === 0) ? a_p / Math.sqrt(A) : (Z % 2 === 1 && N % 2 === 1) ? -a_p / Math.sqrt(A) : 0;
    return volume - surface - coulomb - asymmetry + pairing;
  }

  estimateHalfLife(Z, N) {
    // Placeholder: extremely simplified
    const A = Z + N;
    return Math.pow(10, 25) / (A); // arbitrary units
  }

  estimateDecayModes(Z, N) {
    // Placeholder simple alpha decay for heavy nuclei
    if (Z > 82) {
      return [{ type: 'alpha', probability: 1.0, daughter: { Z: Z - 2, N: N - 2 } }];
    }
    return [];
  }
}
