import { MatterFactory } from './matter_factory.js';
import { Visualizer } from './visualizer.js';
import { Logger } from './logger.js';
import { UIControls } from './ui_controls.js';
import { ReactionEngine } from './reaction_engine.js';
import { HartreeFock } from './hartree_fock.js';
import { EntanglementTracker } from './entanglement.js';
import { VacuumFluctuations } from './vacuum_fluctuations.js';
import { relativisticMass, correctedDecayRate } from './relativistic_corrections.js';
import { AIOptimizer } from './ai_optimizer.js';

class UltimateSimulator {
  constructor(canvasId, logId, uiContainer) {
    this.logger = new Logger(logId);
    this.visualizer = new Visualizer(canvasId);
    this.factory = new MatterFactory();
    this.reactionEngine = new ReactionEngine();
    this.entanglement = new EntanglementTracker();
    this.vacuum = new VacuumFluctuations(1e-14);
    this.optimizer = new AIOptimizer(20, this.fitnessFunction.bind(this));

    this.uiControls = new UIControls(this.handleUIChange.bind(this));
    this.uiControls.attachTo(uiContainer);

    this.atom = this.factory.createAtom(92, 146);
    this.hfSolver = new HartreeFock(this.atom.orbitals.flatMap(o => o.electrons));
    this.simSpeed = 100; // ms per tick

    this.lastTick = 0;
    this.optimizer.initialize({ Z: 92, N: 146 });

    this.logger.log('info', 'Ultimate Simulator initialized');
  }

  fitnessFunction(config) {
    // Higher binding energy = better fitness
    const be = this.factory.estimateBindingEnergy(config.Z, config.N);
    return be || 0;
  }

  handleUIChange(data) {
    if (data.reset) {
      this.atom = this.factory.createAtom(parseInt(data.atomicNumber), parseInt(data.neutronNumber));
      this.hfSolver = new HartreeFock(this.atom.orbitals.flatMap(o => o.electrons));
      this.logger.log('info', `Reset atom to Z=${data.atomicNumber}, N=${data.neutronNumber}`);
    }
    this.simSpeed = parseInt(data.speed);
  }

  simulateTick(delta) {
    // Vacuum fluctuations
    this.vacuum.tick();

    // Hartree-Fock iteration (mock)
    this.hfSolver.iterate();

    // Entanglement decay
    this.entanglement.decay(delta / 1000);

    // Nuclear reactions
    const decay = this.reactionEngine.attemptDecay(this.atom.nucleus);
    if (decay) {
      this.logger.log('decay', `Decay: ${decay.type}, daughter Z=${decay.daughter.Z}, N=${decay.daughter.N}`);
      this.atom = this.factory.createAtom(decay.daughter.Z, decay.daughter.N);
    }

    // AI optimization step every 100 ticks
    if (performance.now() % 10000 < delta) {
      this.optimizer.evolve();
      const best = this.optimizer.population[0];
      this.logger.log('ai', `AI best config: Z=${best.Z}, N=${best.N}, fitness=${this.fitnessFunction(best).toFixed(2)}`);
    }

    // Electrons update
    for (const orbital of this.atom.orbitals) orbital.tick();

    // Visualization
    this.visualizer.render(this.atom.orbitals);
  }

  run(timestamp) {
    if (!this.lastTick) this.lastTick = timestamp;
    const delta = timestamp - this.lastTick;
    if (delta >= this.simSpeed) {
      this.simulateTick(delta);
      this.lastTick = timestamp;
    }
    requestAnimationFrame(this.run.bind(this));
  }
}

export default UltimateSimulator;
