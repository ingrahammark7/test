/* Module 1: potentials.js
   Nuclear potentials and single-particle energy levels
*/

export function woodsSaxonPotential(r, R, a, V0, lsTerm = 0, l = 0, s = 0) {
  // Woods-Saxon potential formula with spin-orbit correction
  const exponent = (r - R) / a;
  const V = -V0 / (1 + Math.exp(exponent));
  // Spin-orbit term approx: lsTerm * (l.s) * derivative factor
  const dVdr = (V0 / a) * Math.exp(exponent) / ((1 + Math.exp(exponent))**2);
  const ls = lsTerm * l * s * (1 / r) * dVdr;
  return V + ls;
}

export function solveRadialSE(Z, N, R=6.5, a=0.5, V0=50, lsTerm=15, maxL=3) {
  // Simplified mock: returns energy levels for l=0..maxL, n=1..3
  let levels = [];
  for(let l=0; l<=maxL; l++) {
    for(let n=1; n<=3; n++) {
      // Simplified formula for energy levels (MeV)
      const energy = -V0 + 10 * n + 5 * l + lsTerm * l * 0.5;
      levels.push({n, l, energy});
    }
  }
  return levels;
}
,
