export class UIControls {
  constructor(onChangeCallback) {
    this.onChangeCallback = onChangeCallback;
    this.container = document.createElement('div');
    this.container.style.textAlign = 'center';
    this.container.style.margin = '10px';

    // Atomic number slider
    this.atomicNumberInput = this._createSlider('Atomic Number (Z)', 1, 118, 92);
    this.container.appendChild(this.atomicNumberInput.container);

    // Neutron number slider
    this.neutronNumberInput = this._createSlider('Neutron Number (N)', 0, 200, 146);
    this.container.appendChild(this.neutronNumberInput.container);

    // Simulation speed
    this.speedInput = this._createSlider('Simulation Speed (ms per tick)', 10, 1000, 100);
    this.container.appendChild(this.speedInput.container);

    // Button to reset simulation
    this.resetButton = document.createElement('button');
    this.resetButton.textContent = 'Reset Simulation';
    this.resetButton.style.marginTop = '10px';
    this.resetButton.onclick = () => this._onReset();
    this.container.appendChild(this.resetButton);
  }

  _createSlider(labelText, min, max, value) {
    const container = document.createElement('div');
    container.style.margin = '8px 0';

    const label = document.createElement('label');
    label.textContent = `${labelText}: ${value}`;
    label.style.display = 'block';

    const input = document.createElement('input');
    input.type = 'range';
    input.min = min;
    input.max = max;
    input.value = value;
    input.style.width = '300px';
    input.oninput = () => {
      label.textContent = `${labelText}: ${input.value}`;
      this.onChangeCallback({
        atomicNumber: this.atomicNumberInput.input.value,
        neutronNumber: this.neutronNumberInput.input.value,
        speed: this.speedInput.input.value,
      });
    };

    container.appendChild(label);
    container.appendChild(input);

    return { container, input };
  }

  _onReset() {
    if (this.onChangeCallback) {
      this.onChangeCallback({
        atomicNumber: this.atomicNumberInput.input.value,
        neutronNumber: this.neutronNumberInput.input.value,
        speed: this.speedInput.input.value,
        reset: true,
      });
    }
  }

  attachTo(parentElement) {
    parentElement.appendChild(this.container);
  }
}
