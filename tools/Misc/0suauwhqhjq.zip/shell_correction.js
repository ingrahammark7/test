// shell_correction.js: Toy Strutinsky shell correction energy calculation

export function strutinskyCorrection(energies) {
  // Smooth energies using simple moving average to get smooth E
  const smooth = [];
  const window = 3;
  for(let i=0; i<energies.length; i++) {
    let sum = 0, count = 0;
    for(let j=i-window; j<=i+window; j++) {
      if(j >=0 && j < energies.length) {
        sum += energies[j];
        count++;
      }
    }
    smooth[i] = sum / count;
  }
  // Correction = sum(raw energies - smooth energies)
  let corr = 0;
  for(let i=0; i<energies.length; i++) {
    corr += energies[i] - smooth[i];
  }
  return corr;
}
