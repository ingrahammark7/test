/* Module 7: quark_models.js
   Simple quark-level nuclear models (MIT Bag, NJL)
*/

export function mitBagEnergy(quarkCount) {
  // MIT Bag energy approx: E = B V + sum quark energies
  const B = 57; // MeV/fm^3 bag constant typical
  const radius = 1.0 * Math.cbrt(quarkCount); // fm
  const volume = (4/3) * Math.PI * Math.pow(radius, 3);
  const quarkEnergy = 300 * quarkCount; // MeV approx per quark
  return B * volume + quarkEnergy;
}

export function njlModelEnergy(params) {
  // Placeholder for NJL model, returns fixed estimate
  return 1000;
}
,
