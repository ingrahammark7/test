while read -r pkg; do
  echo "Installing: $pkg"
  pkg install -y "$pkg" || echo "Failed: $pkg" >> failed.txt
done < f.txt
