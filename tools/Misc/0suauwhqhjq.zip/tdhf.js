// tdhf.js: Time-dependent Hartree-Fock simple step

export function generateHamiltonian(size) {
  let h = [];
  for(let i=0; i<size; i++) {
    h[i] = [];
    for(let j=0; j<size; j++) {
      if(i===j) h[i][j] = 2;
      else if(Math.abs(i-j)===1) h[i][j] = -1;
      else h[i][j] = 0;
    }
  }
  return h;
}

export function TDHFStep(psi, dt, h) {
  let psiNext = [];
  for(let i=0; i<psi.length; i++) {
    let sum = 0;
    for(let j=0; j<psi.length; j++) {
      sum += h[i][j] * psi[j];
    }
    psiNext[i] = psi[i] - dt * sum;
  }
  return psiNext;
}
