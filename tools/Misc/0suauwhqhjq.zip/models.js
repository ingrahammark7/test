// models.js: Lattice EFT sampling and MIT Bag model energy

export function latticeEFTSample(gridSize) {
  let energySum = 0;
  const samples = 1000;
  for(let i=0; i<samples; i++) {
    energySum += -10 + (Math.random() - 0.5) * 2;
  }
  return energySum / samples;
}

export function mitBagEnergy(quarkCount) {
  const B = 57; // MeV/fm^3 bag constant
  const radius = 1.0 * Math.cbrt(quarkCount);
  const volume = (4/3) * Math.PI * Math.pow(radius, 3);
  const quarkEnergy = 300 * quarkCount;
  return B * volume + quarkEnergy;
}
