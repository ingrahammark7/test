export class QuantumStates {
  constructor() {
    // Track occupied states: keys = 'n,l,m,s' strings
    this.occupied = new Set();
  }

  // Check if a quantum state is available
  isAvailable(n, l, m, s) {
    return !this.occupied.has(`${n},${l},${m},${s}`);
  }

  // Occupy a state (returns true if success)
  occupy(n, l, m, s) {
    const key = `${n},${l},${m},${s}`;
    if (this.occupied.has(key)) return false;
    this.occupied.add(key);
    return true;
  }

  // Release a state
  release(n, l, m, s) {
    const key = `${n},${l},${m},${s}`;
    this.occupied.delete(key);
  }

  // Count total electrons occupied
  countElectrons() {
    return this.occupied.size;
  }

  // Generate all possible states for given n and l
  static generateStates(n, l) {
    const states = [];
    for (let m = -l; m <= l; m++) {
      for (let s of [-0.5, 0.5]) {
        states.push({ n, l, m, s });
      }
    }
    return states;
  }
}
