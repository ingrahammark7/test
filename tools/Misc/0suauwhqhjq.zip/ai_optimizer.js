export class AIOptimizer {
  constructor(populationSize, fitnessFunction) {
    this.populationSize = populationSize;
    this.fitnessFunction = fitnessFunction;
    this.population = [];
    this.generation = 0;
  }

  initialize(seedConfig) {
    for (let i = 0; i < this.populationSize; i++) {
      this.population.push(this.mutate(seedConfig));
    }
  }

  mutate(config) {
    let newConfig = { ...config };
    if (Math.random() < 0.5) newConfig.Z = Math.max(1, newConfig.Z + (Math.random() < 0.5 ? 1 : -1));
    if (Math.random() < 0.5) newConfig.N = Math.max(0, newConfig.N + (Math.random() < 0.5 ? 1 : -1));
    return newConfig;
  }

  select() {
    this.population.sort((a, b) => this.fitnessFunction(b) - this.fitnessFunction(a));
    this.population = this.population.slice(0, Math.floor(this.populationSize / 2));
  }

  reproduce() {
    const offspring = [];
    while (offspring.length + this.population.length < this.populationSize) {
      const parent = this.population[Math.floor(Math.random() * this.population.length)];
      offspring.push(this.mutate(parent));
    }
    this.population = this.population.concat(offspring);
  }

  evolve() {
    this.select();
    this.reproduce();
    this.generation++;
  }
}
