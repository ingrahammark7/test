export function relativisticMass(restMass, velocityFraction) {
  if (velocityFraction >= 1) return Infinity;
  return restMass / Math.sqrt(1 - velocityFraction * velocityFraction);
}

export function timeDilationFactor(velocityFraction) {
  if (velocityFraction >= 1) return Infinity;
  return 1 / Math.sqrt(1 - velocityFraction * velocityFraction);
}

export function correctedDecayRate(baseRate, velocityFraction) {
  const dilation = timeDilationFactor(velocityFraction);
  return baseRate / dilation;
}
