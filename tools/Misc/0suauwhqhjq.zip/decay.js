// decay.js: Beta decay half-life and decay chain simulation

export function betaDecayHalfLife(Z, N) {
  const Qbeta = 15 - 0.1 * (N - Z);
  if (Qbeta <= 0) return Infinity;
  return Math.exp(5 / Qbeta);
}

export function simulateDecayChain(Z, N, steps=5) {
  let chain = [{Z, N}];
  for(let i=0; i<steps; i++) {
    if (N <= Z) break;
    N -= 1;
    Z += 1;
    chain.push({Z, N});
  }
  return chain;
}
