// Radioactive decay chains
const nuclei = [];

function initNuclei() {
  for (let i = 0; i < 1000; i++) {
    nuclei.push({ state: "U-238", time: 0 });
  }
}

function decayStep() {
  nuclei.forEach(n => {
    n.time += 1;
    if (n.state === "U-238" && Math.random() < 1e-5) n.state = "Th-234";
    else if (n.state === "Th-234" && Math.random() < 1e-4) n.state = "Pa-234";
    else if (n.state === "Pa-234" && Math.random() < 1e-3) n.state = "U-234";
  });
}

export { initNuclei, decayStep };
