export class Vector {
  static distance(p1, p2) {
    return Math.sqrt((p1.x - p2.x) ** 2 + (p1.y - p2.y) ** 2);
  }

  static direction(p1, p2) {
    const d = this.distance(p1, p2);
    if (d === 0) return { x: 0, y: 0 };
    return { x: (p2.x - p1.x) / d, y: (p2.y - p1.y) / d };
  }

  static scale(vec, scalar) {
    return { x: vec.x * scalar, y: vec.y * scalar };
  }

  static add(v1, v2) {
    return { x: v1.x + v2.x, y: v1.y + v2.y };
  }
}

export function coulombForce(q1, q2, pos1, pos2) {
  const k = 8.9875517923e9; // N·m²/C²
  const r = Vector.distance(pos1, pos2);
  if (r === 0) return { x: 0, y: 0 };
  const magnitude = (k * q1 * q2) / (r * r);
  const dir = Vector.direction(pos1, pos2);
  return Vector.scale(dir, magnitude);
}

export function strongForce(p1, p2) {
  const r = Vector.distance(p1.position, p2.position);
  const range = 1e-15; // femtometer scale
  if (r < range) {
    const magnitude = 1e4 * (range - r); // arbitrary strength
    const dir = Vector.direction(p1.position, p2.position);
    return Vector.scale(dir, magnitude);
  }
  return { x: 0, y: 0 };
}
