// deformation.js: Simple nuclear shape deformation model

export function deformationFactor(beta2) {
  // Beta2 is quadrupole deformation parameter
  // Returns scaling factor for radius along axis
  // R(theta) = R0 * (1 + beta2 * Y20(theta)) approx
  // Y20(theta) = 0.5 * (3*cos^2(theta) - 1)
  function Y20(theta) {
    return 0.5 * (3 * Math.cos(theta) ** 2 - 1);
  }
  return function(theta) {
    return 1 + beta2 * Y20(theta);
  };
}

export function deformedRadius(R0, beta2, theta) {
  const f = deformationFactor(beta2);
  return R0 * f(theta);
}
