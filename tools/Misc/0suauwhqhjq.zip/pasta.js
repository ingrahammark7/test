// pasta.js: Toy nuclear pasta phases via 2D cellular automaton

export function initPastaGrid(size) {
  let grid = [];
  for(let i=0; i<size; i++) {
    grid[i] = [];
    for(let j=0; j<size; j++) {
      grid[i][j] = Math.random() < 0.5 ? 1 : 0; // random initial state
    }
  }
  return grid;
}

export function stepPasta(grid) {
  const size = grid.length;
  let newGrid = [];
  for(let i=0; i<size; i++) {
    newGrid[i] = [];
    for(let j=0; j<size; j++) {
      let neighbors = 0;
      for(let di=-1; di<=1; di++) {
        for(let dj=-1; dj<=1; dj++) {
          if(di===0 && dj===0) continue;
          let ni = (i+di+size) % size;
          let nj = (j+dj+size) % size;
          neighbors += grid[ni][nj];
        }
      }
      // Rule: cell survives if neighbors 2 or 3, birth if 3 neighbors (like Conway's)
      if(grid[i][j] === 1) {
        newGrid[i][j] = (neighbors === 2 || neighbors === 3) ? 1 : 0;
      } else {
        newGrid[i][j] = (neighbors === 3) ? 1 : 0;
      }
    }
  }
  return newGrid;
}
