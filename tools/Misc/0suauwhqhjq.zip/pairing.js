// pairing.js: BCS pairing gap calculation and occupation probabilities

export function bcsPairing(energies, mu, delta) {
  // energies: array of single-particle energies
  // mu: chemical potential
  // delta: pairing gap

  const v2 = energies.map(e => {
    const denom = Math.sqrt((e - mu) ** 2 + delta ** 2);
    return 0.5 * (1 - (e - mu) / denom);
  });
  return v2; // occupation probabilities for each state
}

export function findChemicalPotential(energies, targetN, delta) {
  // Simple bisection to find mu so that sum of v2 equals targetN
  let muLow = Math.min(...energies) - 5;
  let muHigh = Math.max(...energies) + 5;
  const tol = 1e-4;
  let muMid;

  function occupancy(mu) {
    const v2 = bcsPairing(energies, mu, delta);
    return v2.reduce((a,b) => a + b, 0);
  }

  let occLow = occupancy(muLow) - targetN;
  let occHigh = occupancy(muHigh) - targetN;

  if (occLow * occHigh > 0) {
    // No root in range
    return (muLow + muHigh) / 2;
  }

  for(let i=0; i<100; i++) {
    muMid = 0.5 * (muLow + muHigh);
    const occMid = occupancy(muMid) - targetN;
    if (Math.abs(occMid) < tol) break;
    if (occMid * occLow < 0) {
      muHigh = muMid;
      occHigh = occMid;
    } else {
      muLow = muMid;
      occLow = occMid;
    }
  }
  return muMid;
}
