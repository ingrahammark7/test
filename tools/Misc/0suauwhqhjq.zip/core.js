import { initFusion, updateFusion } from "./fusion_core.js";
import { initNuclei, decayStep } from "./decay_chain.js";
import { iterateLattice } from "./lattice_qcd.js";

initFusion();
initNuclei();

function runSimulation() {
  updateFusion();
  decayStep();
  iterateLattice();
  console.log("Simulation ticked.");
}

setInterval(runSimulation, 100); // Run at 10 FPS
