const out = document.getElementById('output');

function log(msg) {
  out.textContent += ;
}

function simulateNuclearProcess() {
  log("Initializing quantum nucleus...");

  let state = {
    protons: 92,
    neutrons: 146,
    energyLevel: 0,
    decayModes: ['alpha', 'beta', 'spontaneous fission'],
  };

  log();

  for (let tick = 1; tick <= 10; tick++) {
    const rand = Math.random();
    log();

    if (rand < 0.33) {
      log("Decay event: Alpha particle emitted.");
      state.protons -= 2;
      state.neutrons -= 2;
    } else if (rand < 0.66) {
      log("Decay event: Beta decay.");
      state.protons += 1;
      state.neutrons -= 1;
    } else {
      log("No decay. Stability maintained.");
    }

    log();
  }

  log("Simulation complete.");
}

document.getElementById('run').addEventListener('click', simulateNuclearProcess);
window.onload = simulateNuclearProcess;
