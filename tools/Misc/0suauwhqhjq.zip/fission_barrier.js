// fission_barrier.js: Toy fission barrier as function of deformation beta2

export function fissionBarrier(beta2) {
  // Use toy formula:
  // Liquid drop: quadratic increase with beta2^2
  // Shell correction: gaussian bump near zero deformation
  const E_ld = 20 * beta2 * beta2;
  const E_shell = 5 * Math.exp(-25 * beta2 * beta2);
  const E_total = E_ld - E_shell;
  return {E_ld, E_shell, E_total};
}
